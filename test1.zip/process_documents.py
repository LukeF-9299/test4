import csv
import re
import asyncio
from typing import List, Dict, Any
from functions import llm_call, embed_call, async_llm_call, batch_llm_calls
from database import DocumentDatabase
from config import (
    CHUNK_SIZE, 
    CHUNK_OVERLAP, 
    NUM_QUESTIONS_PER_DOCUMENT,
    LLM_CONTENT_TRUNCATION,
    LLM_BATCH_SIZE,
    EMBEDDING_BATCH_SIZE,
    LLM_API_URL,
    EMBEDDING_API_URL,
    SAMPLE_DATA_FILE
)

def chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> List[str]:
    """
    Split text into chunks with overlap for embedding.
    
    Args:
        text (str): Input text to chunk
        chunk_size (int): Maximum size of each chunk
        overlap (int): Overlap between chunks
    
    Returns:
        List[str]: List of text chunks
    """
    if len(text) <= chunk_size:
        return [text]
    
    chunks = []
    start = 0
    
    while start < len(text):
        end = start + chunk_size
        
        # If this is not the last chunk, try to break at word boundary
        if end < len(text):
            # Find the last space within the chunk
            last_space = text.rfind(' ', start, end)
            if last_space != -1:
                end = last_space
        
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        
        # Move start position, accounting for overlap
        start = end - overlap if end < len(text) else end
    
    return chunks

def generate_questions(content: str, source: str, num_questions: int = NUM_QUESTIONS_PER_DOCUMENT) -> List[str]:
    """
    Generate questions for a document using LLM.
    
    Args:
        content (str): Document content
        source (str): Document source/title
        num_questions (int): Number of questions to generate
    
    Returns:
        List[str]: List of generated questions
    """
    system_prompt = f"""You are an expert at generating relevant questions from documents. 
Generate {num_questions} diverse and thoughtful questions that can be answered by the provided text.
The questions should cover different aspects of the content and vary in difficulty.
Return only the questions, one per line, without numbering or additional formatting."""

    user_prompt = f"""Document Title: {source}

Document Content:
{content[:LLM_CONTENT_TRUNCATION]}...

Generate {num_questions} questions based on this document content."""

    try:
        response = llm_call(LLM_API_URL, system_prompt, user_prompt)
        
        # Parse response to extract questions
        questions = []
        for line in response.strip().split('\n'):
            line = line.strip()
            # Remove numbering if present
            line = re.sub(r'^\d+\.\s*', '', line)
            # Remove quotes if present
            line = line.strip('"\'')
            if line and len(line) > 10:  # Filter out very short lines
                questions.append(line)
        
        # Ensure we have the requested number of questions
        while len(questions) < num_questions:
            questions.append(f"Sample question about {source}")
        
        return questions[:num_questions]
        
    except Exception as e:
        print(f"Error generating questions for {source}: {e}")
        # Fallback questions
        return [
            f"What are the main points discussed in {source}?",
            f"How does the content of {source} relate to current trends?",
            f"What implications are suggested in the document {source}?"
        ][:num_questions]

async def generate_questions_batch(documents: List[Dict[str, str]]) -> Dict[str, List[str]]:
    """
    Generate questions for multiple documents using async batch processing.
    
    Args:
        documents (List[Dict[str, str]]): List of documents with 'content' and 'source' keys
    
    Returns:
        Dict[str, List[str]]: Dictionary mapping source to list of questions
    """
    system_prompt = f"""You are an expert at generating relevant questions from documents. 
Generate {NUM_QUESTIONS_PER_DOCUMENT} diverse and thoughtful questions that can be answered by the provided text.
The questions should cover different aspects of the content and vary in difficulty.
Return only the questions, one per line, without numbering or additional formatting."""
    
    # Prepare all LLM calls
    all_calls = []
    doc_mapping = []  # To map responses back to documents
    
    for doc in documents:
        content = doc['content']
        source = doc['source']
        
        user_prompt = f"""Document Title: {source}

Document Content:
{content[:LLM_CONTENT_TRUNCATION]}...

Generate {NUM_QUESTIONS_PER_DOCUMENT} questions based on this document content."""
        
        all_calls.append((LLM_API_URL, system_prompt, user_prompt))
        doc_mapping.append(source)
    
    # Process in batches
    all_responses = []
    for i in range(0, len(all_calls), LLM_BATCH_SIZE):
        batch_calls = all_calls[i:i + LLM_BATCH_SIZE]
        print(f"Processing batch {i//LLM_BATCH_SIZE + 1}/{(len(all_calls) + LLM_BATCH_SIZE - 1)//LLM_BATCH_SIZE}")
        
        batch_responses = await batch_llm_calls(batch_calls)
        all_responses.extend(batch_responses)
    
    # Parse responses and map back to documents
    questions_by_source = {}
    
    for i, response in enumerate(all_responses):
        source = doc_mapping[i]
        
        # Parse response to extract questions
        questions = []
        for line in response.strip().split('\n'):
            line = line.strip()
            # Remove numbering if present
            line = re.sub(r'^\d+\.\s*', '', line)
            # Remove quotes if present
            line = line.strip('"\'')
            if line and len(line) > 10:  # Filter out very short lines
                questions.append(line)
        
        # Ensure we have the requested number of questions
        while len(questions) < NUM_QUESTIONS_PER_DOCUMENT:
            questions.append(f"Sample question about {source}")
        
        questions_by_source[source] = questions[:NUM_QUESTIONS_PER_DOCUMENT]
    
    return questions_by_source

def embed_document_chunks(chunks: List[str]) -> List[List[float]]:
    """
    Generate embeddings for document chunks.
    
    Args:
        chunks (List[str]): List of text chunks
    
    Returns:
        List[List[float]]: List of embedding vectors
    """
    if not chunks:
        return []
    
    try:
        embeddings = embed_call(EMBEDDING_API_URL, chunks)
        return embeddings
    except Exception as e:
        print(f"Error generating embeddings: {e}")
        # Return mock embeddings
        return [[0.0] * 384 for _ in chunks]

async def process_documents():
    """
    Process all documents: generate questions and embeddings, store in database.
    """
    total_documents = 0
    total_chunks = 0
    total_questions = 0
    
    # Use database context manager
    with DocumentDatabase() as db:
        # Read the CSV file and collect all documents
        documents = []
        with open(SAMPLE_DATA_FILE, 'r', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            
            for row_num, row in enumerate(reader, 1):
                content = row['content']
                source = row['source']
                documents.append({'content': content, 'source': source})
        
        print(f"Processing {len(documents)} documents...")
        
        # Step 1: Process chunks for all documents
        all_chunks_data = []  # List of (source, content, chunks) tuples
        for i, doc in enumerate(documents, 1):
            content = doc['content']
            source = doc['source']
            
            print(f"Processing document {i}: {source}")
            
            # Chunk the document for embeddings
            chunks = chunk_text(content)
            print(f"  Created {len(chunks)} chunks")
            
            all_chunks_data.append((source, content, chunks))
            total_chunks += len(chunks)
        
        # Step 2: Process embeddings in batches
        print(f"\nGenerating embeddings for {total_chunks} chunks using batch size {EMBEDDING_BATCH_SIZE}...")
        chunk_embeddings = {}  # Use index as key to handle duplicate sources
        
        for i, (source, content, chunks) in enumerate(all_chunks_data, 1):
            print(f"Embedding document {i}/{len(all_chunks_data)}: {source[:50]}...")
            
            # Process chunks in batches
            document_embeddings = []
            for j in range(0, len(chunks), EMBEDDING_BATCH_SIZE):
                batch_chunks = chunks[j:j + EMBEDDING_BATCH_SIZE]
                batch_embeddings = embed_document_chunks(batch_chunks)
                document_embeddings.extend(batch_embeddings)
                
                print(f"  Processed batch {j//EMBEDDING_BATCH_SIZE + 1}/{(len(chunks) + EMBEDDING_BATCH_SIZE - 1)//EMBEDDING_BATCH_SIZE}")
            
            # Ensure we have the right number of embeddings
            if len(document_embeddings) != len(chunks):
                print(f"  Warning: Expected {len(chunks)} embeddings, got {len(document_embeddings)}")
                # Pad or truncate as needed
                while len(document_embeddings) < len(chunks):
                    document_embeddings.append([0.0] * 384)
                document_embeddings = document_embeddings[:len(chunks)]
            
            chunk_embeddings[i-1] = document_embeddings  # Use index as key
        
        # Step 3: Store chunks and embeddings in database
        print(f"\nStoring chunks and embeddings in database...")
        for i, (source, content, chunks) in enumerate(all_chunks_data):
            embeddings = chunk_embeddings[i]  # Use index to get embeddings
            db.store_document_chunks(source, content, chunks, embeddings)
            total_documents += 1
        
        # Step 4: Generate questions using async batch processing
        print(f"\nGenerating questions for {len(documents)} documents using batch processing...")
        questions_by_source = await generate_questions_batch(documents)
        
        # Step 5: Store questions in database
        for source, questions in questions_by_source.items():
            db.store_questions(source, questions)
            total_questions += len(questions)
            print(f"  Stored {len(questions)} questions for: {source[:50]}...")
    
    return {
        "total_documents": total_documents,
        "total_chunks": total_chunks,
        "total_questions": total_questions
    }

def main():
    """Main processing function."""
    print("Starting document processing...")
    print(f"Configuration:")
    print(f"  Chunk size: {CHUNK_SIZE}")
    print(f"  Chunk overlap: {CHUNK_OVERLAP}")
    print(f"  Embedding batch size: {EMBEDDING_BATCH_SIZE}")
    print(f"  Questions per document: {NUM_QUESTIONS_PER_DOCUMENT}")
    print(f"  LLM batch size: {LLM_BATCH_SIZE}")
    print(f"  LLM content truncation: {LLM_CONTENT_TRUNCATION}")
    print()
    
    # Process all documents and store in database
    stats = asyncio.run(process_documents())
    
    # Print summary
    print("\nProcessing complete!")
    print(f"Summary:")
    print(f"  Total documents: {stats['total_documents']}")
    print(f"  Total chunks: {stats['total_chunks']}")
    print(f"  Total questions: {stats['total_questions']}")
    if stats['total_documents'] > 0:
        print(f"  Average chunks per document: {stats['total_chunks'] / stats['total_documents']:.1f}")
        print(f"  Questions per document: {stats['total_questions'] / stats['total_documents']:.1f}")
    
    print(f"\nData stored in SQLite database: documents.db")

if __name__ == "__main__":
    main()
