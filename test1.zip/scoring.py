import numpy as np
from typing import List, Dict, Tuple, Any
from database import DocumentDatabase
from functions import embed_call
from config import TOP_SCORE_THRESHOLD, EMBEDDING_API_URL

def cosine_similarity(vec1: List[float], vec2: List[float]) -> float:
    """
    Calculate cosine similarity between two vectors.
    
    Args:
        vec1 (List[float]): First vector
        vec2 (List[float]): Second vector
    
    Returns:
        float: Cosine similarity score
    """
    vec1_np = np.array(vec1)
    vec2_np = np.array(vec2)
    
    # Calculate cosine similarity
    dot_product = np.dot(vec1_np, vec2_np)
    norm1 = np.linalg.norm(vec1_np)
    norm2 = np.linalg.norm(vec2_np)
    
    if norm1 == 0 or norm2 == 0:
        return 0.0
    
    return dot_product / (norm1 * norm2)

def calculate_question_score(question: str, original_source: str, db: DocumentDatabase, 
                            embedding_table: str = "documents") -> Tuple[float, List[Dict[str, Any]]]:
    """
    Calculate score for a single question by comparing its embedding to document embeddings.
    
    Args:
        question (str): The question to score
        original_source (str): The document source that generated this question
        db (DocumentDatabase): Database connection
        embedding_table (str): Name of the table containing embeddings (default: "documents")
    
    Returns:
        Tuple[float, List[Dict[str, Any]]]: Score and list of similar documents with similarities
    """
    # Embed the question
    question_embedding = embed_call(EMBEDDING_API_URL, [question])[0]
    
    # Get all documents with their embeddings from specified table
    all_documents = []
    
    # Get all unique document sources from specified table
    sources = db.get_all_documents_from_table(embedding_table)
    
    for source in sources:
        chunks = db.get_document_chunks_from_table(source, embedding_table)
        if chunks:
            # Calculate average similarity across all chunks for this document
            chunk_similarities = []
            for chunk_data in chunks:
                similarity = cosine_similarity(question_embedding, chunk_data['embedding'])
                chunk_similarities.append(similarity)
            
            # Use maximum similarity across chunks as the document similarity
            max_similarity = max(chunk_similarities)
            
            all_documents.append({
                'source': source,
                'similarity': max_similarity,
                'chunk_similarities': chunk_similarities
            })
    
    # Sort by similarity (descending)
    all_documents.sort(key=lambda x: x['similarity'], reverse=True)
    
    # Find the rank of the original document
    original_rank = None
    for i, doc in enumerate(all_documents):
        if doc['source'] == original_source:
            original_rank = i + 1  # 1-based ranking
            break
    
    # Calculate score based on ranking
    score = 0.0
    if original_rank is not None:
        if original_rank <= TOP_SCORE_THRESHOLD:
            score = 1.0
        elif original_rank <= 2 * TOP_SCORE_THRESHOLD:
            score = 0.5
        else:
            score = 0.0
    
    return score, all_documents

def score_all_questions(db: DocumentDatabase, embedding_table: str = "documents") -> Dict[str, Any]:
    """
    Score all questions in the database.
    
    Args:
        db (DocumentDatabase): Database connection
    
    Returns:
        Dict[str, Any]: Scoring results and statistics
    """
    # Get all questions with their sources
    all_questions = db.get_all_questions()
    
    # Initialize statistics
    total_questions = 0
    score_1_count = 0
    score_0_5_count = 0
    score_0_count = 0
    total_score = 0.0
    
    # Document-level scoring
    document_scores = {}  # source -> [scores]
    
    print(f"Scoring {len(all_questions)} questions...")
    print(f"Top score threshold: {TOP_SCORE_THRESHOLD}")
    print(f"2x threshold: {2 * TOP_SCORE_THRESHOLD}")
    print()
    
    for i, question_data in enumerate(all_questions, 1):
        question = question_data['question']
        source = question_data['source']
        
        print(f"Processing question {i}/{len(all_questions)} from: {source[:50]}...")
        
        # Calculate score
        score, similar_docs = calculate_question_score(question, source, db, embedding_table)
        
        # Find the rank of original document
        original_rank = None
        for j, doc in enumerate(similar_docs):
            if doc['source'] == source:
                original_rank = j + 1
                break
        
        # Update statistics
        total_questions += 1
        total_score += score
        
        if score == 1.0:
            score_1_count += 1
        elif score == 0.5:
            score_0_5_count += 1
        else:
            score_0_count += 1
        
        # Track document-level scores
        if source not in document_scores:
            document_scores[source] = []
        document_scores[source].append(score)
        
        # Print progress
        if i % 10 == 0 or i == len(all_questions):
            print(f"  Score: {score}, Rank: {original_rank}")
    
    # Calculate document-level statistics
    doc_stats = {}
    for source, scores in document_scores.items():
        doc_stats[source] = {
            'question_count': len(scores),
            'average_score': sum(scores) / len(scores),
            'score_distribution': {
                'score_1_count': sum(1 for s in scores if s == 1.0),
                'score_0_5_count': sum(1 for s in scores if s == 0.5),
                'score_0_count': sum(1 for s in scores if s == 0.0)
            }
        }
    
    # Compile results
    results = {
        'statistics': {
            'total_questions': total_questions,
            'score_1_count': score_1_count,
            'score_0_5_count': score_0_5_count,
            'score_0_count': score_0_count,
            'average_score': total_score / total_questions if total_questions > 0 else 0.0,
            'top_score_threshold': TOP_SCORE_THRESHOLD
        },
        'document_statistics': doc_stats
    }
    
    return results

def print_scoring_results(results: Dict[str, Any]):
    """Print detailed scoring results."""
    stats = results['statistics']
    doc_stats = results['document_statistics']
    
    print("\n" + "="*60)
    print("SCORING RESULTS")
    print("="*60)
    
    print(f"Total questions scored: {stats['total_questions']}")
    print(f"Total documents: {len(doc_stats)}")
    print(f"Top score threshold: {stats['top_score_threshold']}")
    print()
    
    print("Overall Score Distribution:")
    print(f"  Score 1.0 (top {stats['top_score_threshold']}): {stats['score_1_count']} ({stats['score_1_count']/stats['total_questions']*100:.1f}%)")
    print(f"  Score 0.5 (top {2*stats['top_score_threshold']}): {stats['score_0_5_count']} ({stats['score_0_5_count']/stats['total_questions']*100:.1f}%)")
    print(f"  Score 0.0 (below threshold): {stats['score_0_count']} ({stats['score_0_count']/stats['total_questions']*100:.1f}%)")
    print()
    
    print(f"Overall average score: {stats['average_score']:.3f}")
    print()
    
    # Document-level statistics
    print("Document-Level Statistics:")
    print("-" * 40)
    
    # Sort documents by average score
    sorted_docs = sorted(doc_stats.items(), key=lambda x: x[1]['average_score'], reverse=True)
    
    print(f"Top 5 documents by average score:")
    for i, (source, doc_stat) in enumerate(sorted_docs[:5], 1):
        print(f"  {i}. {source[:40]}...")
        print(f"     Questions: {doc_stat['question_count']}")
        print(f"     Avg Score: {doc_stat['average_score']:.3f}")
        print(f"     Score 1.0: {doc_stat['score_distribution']['score_1_count']}")
        print(f"     Score 0.5: {doc_stat['score_distribution']['score_0_5_count']}")
        print(f"     Score 0.0: {doc_stat['score_distribution']['score_0_count']}")
        print()
    
    print(f"Bottom 5 documents by average score:")
    for i, (source, doc_stat) in enumerate(sorted_docs[-5:], 1):
        print(f"  {i}. {source[:40]}...")
        print(f"     Questions: {doc_stat['question_count']}")
        print(f"     Avg Score: {doc_stat['average_score']:.3f}")
        print(f"     Score 1.0: {doc_stat['score_distribution']['score_1_count']}")
        print(f"     Score 0.5: {doc_stat['score_distribution']['score_0_5_count']}")
        print(f"     Score 0.0: {doc_stat['score_distribution']['score_0_count']}")
        print()

def main(embedding_table: str = "documents"):
    """Main scoring function.
    
    Args:
        embedding_table (str): Name of the table containing embeddings to score against
    """
    print("Starting question scoring...")
    print(f"Configuration:")
    print(f"  Embedding table: {embedding_table}")
    print(f"  Top score threshold: {TOP_SCORE_THRESHOLD}")
    print(f"  2x threshold: {2 * TOP_SCORE_THRESHOLD}")
    print()
    
    # Connect to database
    with DocumentDatabase() as db:
        # Score all questions
        results = score_all_questions(db, embedding_table)
        
        # Print results
        print_scoring_results(results)
        
        # Save results to file with table name in filename
        import json
        output_filename = f'scoring_results_{embedding_table}.json'
        with open(output_filename, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        
        print(f"\nDetailed results saved to: {output_filename}")

if __name__ == "__main__":
    main()
