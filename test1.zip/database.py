import sqlite3
import json
import numpy as np
from typing import List, Dict, Any, Optional
from config import OUTPUT_FILE

class DocumentDatabase:
    """SQLite database for storing document embeddings and questions."""
    
    def __init__(self, db_path: str = "documents.db"):
        """Initialize database connection and create tables."""
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self.cursor = self.conn.cursor()
        self.create_tables()
    
    def create_tables(self):
        """Create necessary tables if they don't exist."""
        # Documents table
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT NOT NULL,
                content TEXT NOT NULL,
                chunk_index INTEGER NOT NULL,
                chunk_text TEXT NOT NULL,
                embedding BLOB NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Questions table
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS questions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                document_source TEXT NOT NULL,
                question TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (document_source) REFERENCES documents (source)
            )
        ''')
        
        # Create indexes for better performance
        self.cursor.execute('CREATE INDEX IF NOT EXISTS idx_documents_source ON documents (source)')
        self.cursor.execute('CREATE INDEX IF NOT EXISTS idx_questions_source ON questions (document_source)')
        
        self.conn.commit()
    
    def create_embedding_table(self, table_name: str):
        """Create a new embedding table with the same structure as documents table.
        
        Args:
            table_name (str): Name for the new embedding table
        """
        self.cursor.execute(f'''
            CREATE TABLE IF NOT EXISTS {table_name} (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT NOT NULL,
                content TEXT NOT NULL,
                chunk_index INTEGER NOT NULL,
                chunk_text TEXT NOT NULL,
                embedding BLOB NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Create index for better performance
        self.cursor.execute(f'CREATE INDEX IF NOT EXISTS idx_{table_name}_source ON {table_name} (source)')
        
        self.conn.commit()
        print(f"Created embedding table: {table_name}")
    
    def copy_embeddings_to_table(self, source_table: str = "documents", target_table: str = None):
        """Copy embeddings from one table to another (for testing different embedding models).
        
        Args:
            source_table (str): Source table name
            target_table (str): Target table name (if None, creates a copy with suffix)
        """
        if target_table is None:
            target_table = f"{source_table}_copy"
        
        # Create target table if it doesn't exist
        self.create_embedding_table(target_table)
        
        # Copy data
        self.cursor.execute(f'''
            INSERT INTO {target_table} (source, content, chunk_index, chunk_text, embedding, created_at)
            SELECT source, content, chunk_index, chunk_text, embedding, created_at
            FROM {source_table}
        ''')
        
        self.conn.commit()
        print(f"Copied embeddings from {source_table} to {target_table}")
        
        # Get count
        self.cursor.execute(f'SELECT COUNT(*) FROM {target_table}')
        count = self.cursor.fetchone()[0]
        print(f"Target table now has {count} embeddings")
    
    def embedding_to_blob(self, embedding: List[float]) -> bytes:
        """Convert embedding list to binary blob for storage."""
        # Convert to numpy array and then to binary
        embedding_array = np.array(embedding, dtype=np.float32)
        return embedding_array.tobytes()
    
    def blob_to_embedding(self, blob: bytes) -> List[float]:
        """Convert binary blob back to embedding list."""
        embedding_array = np.frombuffer(blob, dtype=np.float32)
        return embedding_array.tolist()
    
    def store_document_chunks(self, source: str, content: str, chunks: List[str], embeddings: List[List[float]]):
        """Store document chunks and their embeddings."""
        if len(chunks) != len(embeddings):
            raise ValueError("Number of chunks must match number of embeddings")
        
        for i, (chunk, embedding) in enumerate(zip(chunks, embeddings)):
            embedding_blob = self.embedding_to_blob(embedding)
            self.cursor.execute('''
                INSERT INTO documents (source, content, chunk_index, chunk_text, embedding)
                VALUES (?, ?, ?, ?, ?)
            ''', (source, content, i, chunk, embedding_blob))
        
        self.conn.commit()
        print(f"Stored {len(chunks)} chunks for document: {source}")
    
    def store_questions(self, source: str, questions: List[str]):
        """Store questions for a document."""
        for question in questions:
            self.cursor.execute('''
                INSERT INTO questions (document_source, question)
                VALUES (?, ?)
            ''', (source, question))
        
        self.conn.commit()
        print(f"Stored {len(questions)} questions for document: {source}")
    
    def get_document_chunks(self, source: str) -> List[Dict[str, Any]]:
        """Retrieve all chunks and embeddings for a document."""
        self.cursor.execute('''
            SELECT chunk_index, chunk_text, embedding 
            FROM documents 
            WHERE source = ? 
            ORDER BY chunk_index
        ''', (source,))
        
        chunks = []
        for row in self.cursor.fetchall():
            chunk_index, chunk_text, embedding_blob = row
            embedding = self.blob_to_embedding(embedding_blob)
            chunks.append({
                'chunk_index': chunk_index,
                'chunk_text': chunk_text,
                'embedding': embedding
            })
        
        return chunks
    
    def get_questions(self, source: str) -> List[str]:
        """Retrieve all questions for a document."""
        self.cursor.execute('''
            SELECT question FROM questions 
            WHERE document_source = ?
        ''', (source,))
        
        return [row[0] for row in self.cursor.fetchall()]
    
    def get_all_documents(self) -> List[str]:
        """Get list of all document sources."""
        self.cursor.execute('SELECT DISTINCT source FROM documents ORDER BY source')
        return [row[0] for row in self.cursor.fetchall()]
    
    def get_all_documents_from_table(self, table_name: str = "documents") -> List[str]:
        """Get list of all document sources from specified table."""
        self.cursor.execute(f'SELECT DISTINCT source FROM {table_name} ORDER BY source')
        return [row[0] for row in self.cursor.fetchall()]
    
    def get_all_questions(self) -> List[Dict[str, str]]:
        """Get all questions with their document sources."""
        self.cursor.execute('''
            SELECT document_source, question 
            FROM questions 
            ORDER BY document_source
        ''')
        
        return [{'source': row[0], 'question': row[1]} for row in self.cursor.fetchall()]
    
    def get_document_chunks_from_table(self, source: str, table_name: str = "documents") -> List[Dict[str, Any]]:
        """Retrieve all chunks and embeddings for a document from specified table."""
        self.cursor.execute(f'''
            SELECT chunk_index, chunk_text, embedding 
            FROM {table_name} 
            WHERE source = ? 
            ORDER BY chunk_index
        ''', (source,))
        
        chunks = []
        for row in self.cursor.fetchall():
            chunk_index, chunk_text, embedding_blob = row
            embedding = self.blob_to_embedding(embedding_blob)
            chunks.append({
                'chunk_index': chunk_index,
                'chunk_text': chunk_text,
                'embedding': embedding
            })
        
        return chunks
    
    def search_similar_chunks(self, query_embedding: List[float], limit: int = 5) -> List[Dict[str, Any]]:
        """Find chunks most similar to a query embedding (mock implementation)."""
        # This is a mock similarity search - in a real implementation,
        # you would use proper vector similarity metrics
        self.cursor.execute('''
            SELECT source, chunk_index, chunk_text, embedding 
            FROM documents 
            ORDER BY RANDOM()
            LIMIT ?
        ''', (limit,))
        
        results = []
        for row in self.cursor.fetchall():
            source, chunk_index, chunk_text, embedding_blob = row
            embedding = self.blob_to_embedding(embedding_blob)
            
            # Mock similarity score (random for now)
            similarity_score = np.random.random()
            
            results.append({
                'source': source,
                'chunk_index': chunk_index,
                'chunk_text': chunk_text,
                'embedding': embedding,
                'similarity_score': similarity_score
            })
        
        return sorted(results, key=lambda x: x['similarity_score'], reverse=True)
    
    def get_database_stats(self) -> Dict[str, int]:
        """Get database statistics."""
        self.cursor.execute('SELECT COUNT(*) FROM documents')
        doc_chunks_count = self.cursor.fetchone()[0]
        
        self.cursor.execute('SELECT COUNT(DISTINCT source) FROM documents')
        doc_count = self.cursor.fetchone()[0]
        
        self.cursor.execute('SELECT COUNT(*) FROM questions')
        question_count = self.cursor.fetchone()[0]
        
        return {
            'total_documents': doc_count,
            'total_chunks': doc_chunks_count,
            'total_questions': question_count
        }
    
    def close(self):
        """Close database connection."""
        self.conn.close()
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()

def load_processed_data_to_database(json_file: str = OUTPUT_FILE, db_path: str = "documents.db"):
    """Load processed data from JSON file into SQLite database."""
    try:
        with open(json_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except FileNotFoundError:
        print(f"Error: Could not find processed data file {json_file}")
        return
    
    with DocumentDatabase(db_path) as db:
        for doc in data['documents']:
            # Store document chunks and embeddings
            db.store_document_chunks(
                source=doc['source'],
                content=doc['content'],
                chunks=doc['chunks'],
                embeddings=doc['embeddings']
            )
            
            # Store questions
            db.store_questions(
                source=doc['source'],
                questions=doc['questions']
            )
        
        # Print statistics
        stats = db.get_database_stats()
        print(f"\nDatabase loading complete!")
        print(f"Statistics:")
        print(f"  Total documents: {stats['total_documents']}")
        print(f"  Total chunks: {stats['total_chunks']}")
        print(f"  Total questions: {stats['total_questions']}")

if __name__ == "__main__":
    # Test database functionality
    print("Testing database functionality...")
    
    # Load data from JSON file if it exists
    load_processed_data_to_database()
    
    # Test retrieval
    with DocumentDatabase() as db:
        print("\nTesting data retrieval:")
        
        # Get all document sources
        documents = db.get_all_documents()
        print(f"Found {len(documents)} documents")
        
        if documents:
            # Get chunks for first document
            first_doc = documents[0]
            chunks = db.get_document_chunks(first_doc)
            print(f"Document '{first_doc}' has {len(chunks)} chunks")
            
            # Get questions for first document
            questions = db.get_questions(first_doc)
            print(f"Document '{first_doc}' has {len(questions)} questions")
            
            if questions:
                print(f"First question: {questions[0]}")
        
        # Get database stats
        stats = db.get_database_stats()
        print(f"\nDatabase statistics: {stats}")
