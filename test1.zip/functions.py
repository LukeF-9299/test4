import random
import json
import asyncio
import aiohttp
from typing import List, Union

def llm_call(url: str, system_prompt: str, user_prompt: str) -> str:
    """
    Mock LLM call function for testing purposes.
    
    Args:
        url (str): The URL of the LLM service (mock)
        system_prompt (str): System prompt for the LLM
        user_prompt (str): User prompt for the LLM
    
    Returns:
        str: Mock LLM response
    """
    # Mock response generation based on prompt content
    responses = [
        f"This is a mock response to: '{user_prompt[:50]}...' The system prompt was: '{system_prompt[:30]}...'",
        f"Based on your request about {user_prompt.split()[:3]}, I would suggest considering multiple approaches. The system context indicates we should focus on {system_prompt.split()[:3]}.",
        f"Processing your input: {user_prompt}. System guidance: {system_prompt}. Here's a simulated LLM response with relevant insights.",
        f"Mock analysis complete. For your query regarding {user_prompt[:30]}, considering the system directive '{system_prompt[:30]}', here are my recommendations.",
        f"Simulated LLM output: Your request '{user_prompt[:40]}' has been processed with system context '{system_prompt[:40]}'. This is a test response."
    ]
    
    # Add some variation based on input length and content
    hash_input = len(user_prompt) + len(system_prompt) + len(url)
    selected_response = responses[hash_input % len(responses)]
    
    # Add some mock detailed content
    mock_details = [
        "Key findings include improved efficiency and accuracy.",
        "The analysis reveals several important patterns.",
        "Further investigation may yield additional insights.",
        "Current results are promising but require validation.",
        "The approach shows potential for scalability."
    ]
    
    detail = mock_details[hash_input % len(mock_details)]
    
    return f"{selected_response} {detail} URL used: {url}"

async def async_llm_call(url: str, system_prompt: str, user_prompt: str) -> str:
    """
    Async mock LLM call function for testing purposes.
    
    Args:
        url (str): The URL of the LLM service (mock)
        system_prompt (str): System prompt for the LLM
        user_prompt (str): User prompt for the LLM
    
    Returns:
        str: Mock LLM response
    """
    # Simulate async delay
    await asyncio.sleep(0.1)
    
    # Use the same logic as synchronous version
    responses = [
        f"This is a mock response to: '{user_prompt[:50]}...' The system prompt was: '{system_prompt[:30]}...'",
        f"Based on your request about {user_prompt.split()[:3]}, I would suggest considering multiple approaches. The system context indicates we should focus on {system_prompt.split()[:3]}.",
        f"Processing your input: {user_prompt}. System guidance: {system_prompt}. Here's a simulated LLM response with relevant insights.",
        f"Mock analysis complete. For your query regarding {user_prompt[:30]}, considering the system directive '{system_prompt[:30]}', here are my recommendations.",
        f"Simulated LLM output: Your request '{user_prompt[:40]}' has been processed with system context '{system_prompt[:40]}'. This is a test response."
    ]
    
    # Add some variation based on input length and content
    hash_input = len(user_prompt) + len(system_prompt) + len(url)
    selected_response = responses[hash_input % len(responses)]
    
    # Add some mock detailed content
    mock_details = [
        "Key findings include improved efficiency and accuracy.",
        "The analysis reveals several important patterns.",
        "Further investigation may yield additional insights.",
        "Current results are promising but require validation.",
        "The approach shows potential for scalability."
    ]
    
    detail = mock_details[hash_input % len(mock_details)]
    
    return f"{selected_response} {detail} URL used: {url}"

async def batch_llm_calls(calls: List[tuple]) -> List[str]:
    """
    Process multiple LLM calls concurrently in batches.
    
    Args:
        calls (List[tuple]): List of (url, system_prompt, user_prompt) tuples
    
    Returns:
        List[str]: List of responses in the same order as input
    """
    tasks = []
    for url, system_prompt, user_prompt in calls:
        task = async_llm_call(url, system_prompt, user_prompt)
        tasks.append(task)
    
    responses = await asyncio.gather(*tasks)
    return responses

def embed_call(url: str, texts: List[str]) -> List[List[float]]:
    """
    Mock embedding call function for testing purposes.
    
    Args:
        url (str): The URL of the embedding service (mock)
        texts (List[str]): List of texts to embed
    
    Returns:
        List[List[float]]: Mock embeddings for each input text
    """
    embeddings = []
    
    for i, text in enumerate(texts):
        # Generate mock embedding based on text characteristics
        text_length = len(text)
        word_count = len(text.split())
        
        # Create a deterministic but varied embedding vector
        # Using 384 dimensions (common for sentence transformers)
        embedding = []
        for j in range(384):
            # Create pseudo-random but deterministic values
            base_value = (text_length + word_count + i + j) % 100
            normalized_value = (base_value / 100.0) * 2 - 1  # Normalize to [-1, 1]
            
            # Add some variation based on text content
            if j % 3 == 0:
                normalized_value *= (text_length % 10) / 10.0
            elif j % 3 == 1:
                normalized_value *= (word_count % 10) / 10.0
            
            embedding.append(round(normalized_value, 6))
        
        embeddings.append(embedding)
    
    # Add mock metadata
    print(f"Generated {len(embeddings)} embeddings from {url}")
    print(f"Embedding dimensions: {len(embeddings[0])} if embeddings else 'N/A'")
    
    return embeddings

# Test functions
if __name__ == "__main__":
    # Test llm_call
    print("Testing llm_call:")
    test_url = "https://mock-llm-api.example.com"
    test_system = "You are a helpful assistant."
    test_user = "What is the meaning of life?"
    
    llm_response = llm_call(test_url, test_system, test_user)
    print(f"LLM Response: {llm_response}")
    print()
    
    # Test embed_call
    print("Testing embed_call:")
    test_texts = [
        "This is a sample text for embedding.",
        "Another sample text with different content.",
        "Third text sample for testing purposes."
    ]
    
    embeddings = embed_call(test_url, test_texts)
    print(f"Number of embeddings: {len(embeddings)}")
    print(f"First embedding length: {len(embeddings[0])}")
    print(f"First 5 values of first embedding: {embeddings[0][:5]}")
    print()
