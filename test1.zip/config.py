# Configuration settings for document processing

# Embedding settings
CHUNK_SIZE = 500  # Maximum characters per chunk for embedding
CHUNK_OVERLAP = 50  # Overlap between chunks in characters
EMBEDDING_BATCH_SIZE = 30  # Number of chunks to embed at once

# Question generation settings
NUM_QUESTIONS_PER_DOCUMENT = 3  # Number of questions to generate per document
LLM_CONTENT_TRUNCATION = 2000  # Maximum characters to send to LLM for question generation
LLM_BATCH_SIZE = 5  # Number of concurrent LLM requests in batch processing

# Scoring settings
TOP_SCORE_THRESHOLD = 10  # Threshold for scoring system

# API endpoints (mock URLs for testing)
LLM_API_URL = "https://api.mock-llm.com/v1/chat"
EMBEDDING_API_URL = "https://api.mock-embeddings.com/v1/embed"

# File paths
SAMPLE_DATA_FILE = "sample_data.csv"
OUTPUT_FILE = "processed_documents.json"
