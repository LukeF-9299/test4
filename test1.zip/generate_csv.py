import csv
import random
import string

# Sample text content templates
text_templates = [
    "The rapid advancement of artificial intelligence has transformed numerous industries, from healthcare to finance. Machine learning algorithms now power everything from recommendation systems to autonomous vehicles. As we continue to push the boundaries of what's possible, ethical considerations become increasingly important. The development of AI systems must be guided by principles of fairness, transparency, and accountability. Researchers and developers must work together to ensure that AI benefits all of humanity while minimizing potential risks and unintended consequences.",
    
    "Climate change represents one of the most significant challenges facing our generation. Rising global temperatures, melting ice caps, and extreme weather events are clear indicators of a planet in distress. Scientists worldwide agree that immediate action is necessary to prevent catastrophic consequences. Renewable energy technologies, sustainable agriculture practices, and conservation efforts offer hope for a more sustainable future. International cooperation and individual responsibility are both crucial in addressing this global crisis.",
    
    "The digital revolution has fundamentally changed how we communicate, work, and live. Social media platforms have connected billions of people across the globe, while remote work technologies have transformed traditional office environments. However, this connectivity comes with challenges, including privacy concerns, digital divide issues, and the spread of misinformation. Finding the right balance between technological progress and human wellbeing remains an ongoing challenge for society.",
    
    "Education systems worldwide are evolving to meet the demands of the 21st century. Traditional teaching methods are being supplemented with digital learning tools, personalized education approaches, and skills-based curricula. The COVID-19 pandemic accelerated this transformation, forcing educators and students to adapt to online learning environments. As we look to the future, hybrid learning models and lifelong education initiatives will likely become increasingly important.",
    
    "Healthcare innovation has led to remarkable improvements in human longevity and quality of life. From vaccines and antibiotics to surgical techniques and diagnostic tools, medical science continues to push boundaries. Personalized medicine, gene therapy, and AI-assisted diagnostics represent the next frontier in healthcare. However, access to these innovations remains unequal, highlighting the need for more inclusive healthcare policies and systems.",
    
    "Urbanization trends are reshaping our world, with more people living in cities than ever before. Smart city initiatives, sustainable architecture, and efficient public transportation systems are becoming increasingly important. However, rapid urban growth also presents challenges, including housing shortages, traffic congestion, and environmental impacts. Planning for sustainable urban development requires careful consideration of social, economic, and environmental factors.",
    
    "The global economy has become increasingly interconnected, with supply chains spanning multiple continents and digital platforms enabling instant transactions. This interconnectedness brings opportunities for growth and innovation, but also creates vulnerabilities. Economic crises in one region can quickly spread globally, highlighting the need for international cooperation and resilient economic systems.",
    
    "Space exploration continues to capture human imagination and drive technological innovation. From satellite communications to planetary exploration missions, space technology has numerous practical applications on Earth. Private companies are now playing an increasingly important role in space exploration, potentially accelerating progress toward ambitious goals like Mars colonization and asteroid mining.",
    
    "Biotechnology advances are revolutionizing medicine, agriculture, and environmental science. Gene editing technologies like CRISPR offer the potential to cure genetic diseases, improve crop yields, and address environmental challenges. However, these technologies also raise important ethical questions about genetic modification and its long-term consequences for ecosystems and human society.",
    
    "The internet has transformed from a simple communication tool into a global platform for commerce, education, entertainment, and social interaction. Web technologies continue to evolve rapidly, with artificial intelligence, virtual reality, and blockchain promising to reshape our digital experiences. However, issues of digital privacy, cybersecurity, and online harassment remain significant challenges that need to be addressed."
]

# Sample document titles
document_titles = [
    "Annual Report on Climate Change Impacts",
    "The Future of Artificial Intelligence in Healthcare",
    "Digital Transformation Strategies for Modern Businesses",
    "Sustainable Urban Development: Challenges and Solutions",
    "Global Economic Trends and Market Analysis",
    "Advances in Biotechnology and Medical Research",
    "Space Exploration: The Next Frontier",
    "Education Reform in the Digital Age",
    "Renewable Energy Technologies and Implementation",
    "Cybersecurity Best Practices for Organizations",
    "The Psychology of Remote Work and Productivity",
    "Supply Chain Management in Global Markets",
    "Environmental Conservation and Biodiversity Protection",
    "Social Media Impact on Society and Communication",
    "Innovation in Agricultural Technology",
    "Healthcare Systems: Lessons from Global Pandemics",
    "Financial Technology and Digital Banking Evolution",
    "Robotics and Automation in Manufacturing",
    "Data Science Applications in Business Intelligence",
    "Sustainable Tourism and Travel Industry Trends",
    "Mental Health in the Digital Era",
    "Blockchain Technology Beyond Cryptocurrency",
    "Quantum Computing: Theory and Applications",
    "Renewable Energy Storage Solutions",
    "Smart Cities: Infrastructure and Technology",
    "Artificial Intelligence Ethics and Governance",
    "Climate Resilience and Adaptation Strategies",
    "Personalized Medicine and Genomic Research",
    "Digital Privacy and Data Protection Regulations",
    "Sustainable Fashion and Textile Industry",
    "Food Security and Agricultural Innovation",
    "Water Management and Conservation Technologies",
    "Air Quality Monitoring and Improvement",
    "Waste Reduction and Circular Economy Models",
    "Electric Vehicle Infrastructure Development",
    "Green Building Design and Construction",
    "Ocean Conservation and Marine Protection",
    "Forest Management and Reforestation Efforts",
    "Wildlife Conservation and Habitat Restoration",
    "Carbon Capture and Storage Technologies",
    "Sustainable Mining and Resource Extraction",
    "Eco-friendly Transportation Systems",
    "Energy Efficiency in Buildings and Industry",
    "Sustainable Packaging Solutions",
    "Environmental Impact Assessment Methods",
    "Climate Change Mitigation Policies",
    "Renewable Energy Grid Integration",
    "Sustainable Waste Management Practices",
    "Green Chemistry and Sustainable Materials",
    "Biodiversity Monitoring and Conservation",
    "Ecosystem Restoration Techniques",
    "Sustainable Fisheries Management",
    "Agricultural Sustainability Practices",
    "Urban Green Spaces and Planning",
    "Sustainable Water Resource Management",
    "Climate-smart Agriculture Development",
    "Environmental Education and Awareness",
    "Sustainable Tourism Practices",
    "Green Supply Chain Management",
    "Sustainable Investment Strategies",
    "Environmental Policy and Regulation",
    "Climate Adaptation Planning",
    "Sustainable Development Goals Progress",
    "Environmental Technology Innovation",
    "Green Business Practices",
    "Sustainable Consumption Patterns",
    "Climate Finance and Investment",
    "Environmental Risk Assessment",
    "Sustainable Energy Policies",
    "Green Infrastructure Development",
    "Climate Resilience Planning",
    "Sustainable Urban Mobility",
    "Environmental Monitoring Systems",
    "Green Manufacturing Processes",
    "Sustainable Food Systems",
    "Climate Education and Outreach",
    "Environmental Justice and Equity",
    "Sustainable Resource Management",
    "Green Technology Adoption",
    "Climate Change Communication",
    "Sustainable Lifestyle Choices",
    "Environmental Leadership Development",
    "Green Job Creation Strategies",
    "Climate Action Planning",
    "Sustainable Community Development",
    "Environmental Innovation Hubs",
    "Green Economic Growth Models",
    "Climate Resilient Infrastructure",
    "Sustainable Transportation Planning",
    "Environmental Health and Safety",
    "Green Building Certification Systems",
    "Climate-smart Urban Planning",
    "Sustainable Waste Reduction",
    "Environmental Performance Metrics",
    "Green Technology Transfer",
    "Climate Adaptation Technologies",
    "Sustainable Energy Access",
    "Environmental Capacity Building",
    "Green Business Transformation",
    "Climate Resilience Measurement"
]

def generate_sample_text():
    """Generate sample text between 500-1000 words"""
    # Start with a random template
    base_text = random.choice(text_templates)
    
    # Add random sentences to expand the text
    additional_sentences = [
        "This development represents a significant milestone in our ongoing efforts to address complex challenges.",
        "Experts emphasize the importance of collaborative approaches and interdisciplinary cooperation.",
        "The implications of these changes extend far beyond immediate concerns, affecting future generations.",
        "Research indicates that proactive measures can significantly reduce potential negative outcomes.",
        "Stakeholder engagement remains crucial for successful implementation of these strategies.",
        "Technology continues to evolve at an unprecedented pace, creating new opportunities and challenges.",
        "Policy frameworks must adapt to changing circumstances while maintaining core principles.",
        "International standards and best practices provide valuable guidance for local implementation.",
        "Data-driven decision making enables more effective resource allocation and impact assessment.",
        "Continuous monitoring and evaluation ensure that programs remain responsive to emerging needs.",
        "Innovation ecosystems thrive when supported by appropriate infrastructure and investment.",
        "Capacity building initiatives strengthen institutional resilience and adaptive capabilities.",
        "Public-private partnerships leverage complementary strengths and shared objectives.",
        "Community participation ensures that solutions are contextually appropriate and sustainable.",
        "Evidence-based approaches maximize the efficiency and effectiveness of interventions."
    ]
    
    # Add random number of additional sentences
    num_sentences = random.randint(15, 30)
    for _ in range(num_sentences):
        base_text += " " + random.choice(additional_sentences)
    
    # Ensure word count is between 500-1000
    words = base_text.split()
    if len(words) < 500:
        # Add more sentences if too short
        while len(words) < 500:
            base_text += " " + random.choice(additional_sentences)
            words = base_text.split()
    elif len(words) > 1000:
        # Trim if too long
        base_text = " ".join(words[:1000])
    
    return base_text

def generate_csv():
    """Generate CSV with 100 sample rows"""
    filename = "sample_data.csv"
    
    with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = ['content', 'source']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        writer.writeheader()
        
        for i in range(100):
            content = generate_sample_text()
            source = random.choice(document_titles)
            
            writer.writerow({'content': content, 'source': source})
            
            if (i + 1) % 10 == 0:
                print(f"Generated {i + 1} rows...")
    
    print(f"CSV file '{filename}' created successfully with 100 rows!")
    print("Each content entry contains 500-1000 words.")
    print("Each source entry contains a document title.")

if __name__ == "__main__":
    generate_csv()
