# LLM API Gateway - User Guide

## Overview

The LLM API Gateway provides a single, unified endpoint for accessing multiple language models and embedding models across different servers. All models are accessible through OpenAI-compatible APIs using the same authentication and request format.

## Base URL

```
http://your-gateway-host:8080
```

## Authentication

All API requests require an API key sent as a Bearer token:

```bash
Authorization: Bearer YOUR_API_KEY
```

## Getting Started

### 1. List Available Models

First, see what models are available:

```bash
curl -H "Authorization: Bearer YOUR_API_KEY" \
  http://localhost:8080/v1/models
```

**Response Example:**
```json
{
  "object": "list",
  "data": [
    {
      "id": "llama-3-8b",
      "object": "model",
      "created": 1640995200,
      "owned_by": "llm-server-1, llm-server-2 (2 servers)"
    },
    {
      "id": "llama-3-70b", 
      "object": "model",
      "created": 1640995200,
      "owned_by": "llm-server-1 (1 server)"
    },
    {
      "id": "text-embedding-ada-002",
      "object": "model", 
      "created": 1640995200,
      "owned_by": "embedding-server (1 server)"
    }
  ]
}
```

### 2. Choose Your Model Type

- **LLM Models** (for chat/completions): Use `/v1/chat/completions`
- **Embedding Models** (for text embeddings): Use `/v1/embeddings`

## Using LLM Models (Chat Completions)

### Basic Chat Request

```bash
curl -X POST http://localhost:8080/v1/chat/completions \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "llama-3-8b",
    "messages": [
      {"role": "user", "content": "Hello! How are you?"}
    ]
  }'
```

**Response Example:**
```json
{
  "id": "chatcmpl-abc123",
  "object": "chat.completion",
  "created": 1640995200,
  "model": "llama-3-8b",
  "choices": [
    {
      "index": 0,
      "message": {
        "role": "assistant",
        "content": "Hello! I'm doing well, thank you for asking. How can I help you today?"
      },
      "finish_reason": "stop"
    }
  ],
  "usage": {
    "prompt_tokens": 10,
    "completion_tokens": 15,
    "total_tokens": 25
  }
}
```

### Advanced Chat Options

```bash
curl -X POST http://localhost:8080/v1/chat/completions \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "llama-3-8b",
    "messages": [
      {"role": "system", "content": "You are a helpful assistant."},
      {"role": "user", "content": "Explain quantum computing in simple terms."}
    ],
    "temperature": 0.7,
    "max_tokens": 500,
    "stream": false
  }'
```

**Parameters:**
- `model` (required): Model name from the models list
- `messages` (required): Array of message objects
- `temperature` (optional): 0.0-2.0, controls randomness (default: 1.0)
- `max_tokens` (optional): Maximum tokens in response
- `stream` (optional): Enable streaming response (default: false)

### Streaming Responses

```bash
curl -X POST http://localhost:8080/v1/chat/completions \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "llama-3-8b",
    "messages": [
      {"role": "user", "content": "Tell me a story"}
    ],
    "stream": true
  }'
```

**Streaming Response:**
```
data: {"id":"chatcmpl-abc123","object":"chat.completion.chunk","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}]}
data: {"id":"chatcmpl-abc123","object":"chat.completion.chunk","choices":[{"index":0,"delta":{"content":"Once"},"finish_reason":null}]}
data: {"id":"chatcmpl-abc123","object":"chat.completion.chunk","choices":[{"index":0,"delta":{"content":" upon"},"finish_reason":null}]}
data: [DONE]
```

## Using Embedding Models

### Single Text Embedding

```bash
curl -X POST http://localhost:8080/v1/embeddings \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "text-embedding-ada-002",
    "input": "Hello, world!"
  }'
```

**Response Example:**
```json
{
  "object": "list",
  "data": [
    {
      "object": "embedding",
      "index": 0,
      "embedding": [0.0023, -0.0017, 0.0045, ...]  // Array of floats
    }
  ],
  "model": "text-embedding-ada-002",
  "usage": {
    "prompt_tokens": 3,
    "total_tokens": 3
  }
}
```

### Multiple Text Embeddings

```bash
curl -X POST http://localhost:8080/v1/embeddings \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "text-embedding-ada-002",
    "input": [
      "First text to embed",
      "Second text to embed",
      "Third text to embed"
    ]
  }'
```

**Response Example:**
```json
{
  "object": "list",
  "data": [
    {
      "object": "embedding",
      "index": 0,
      "embedding": [0.0023, -0.0017, 0.0045, ...]
    },
    {
      "object": "embedding", 
      "index": 1,
      "embedding": [0.0018, -0.0021, 0.0039, ...]
    },
    {
      "object": "embedding",
      "index": 2, 
      "embedding": [0.0027, -0.0013, 0.0041, ...]
    }
  ],
  "model": "text-embedding-ada-002",
  "usage": {
    "prompt_tokens": 15,
    "total_tokens": 15
  }
}
```

## Python Examples

### Chat Completion Example

```python
import requests

# Configuration
BASE_URL = "http://localhost:8080"
API_KEY = "your-api-key-here"

headers = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json"
}

# List models
response = requests.get(f"{BASE_URL}/v1/models", headers=headers)
models = response.json()
print("Available models:", [model["id"] for model in models["data"]])

# Chat completion
chat_data = {
    "model": "llama-3-8b",
    "messages": [
        {"role": "user", "content": "What is the capital of France?"}
    ]
}

response = requests.post(f"{BASE_URL}/v1/chat/completions", headers=headers, json=chat_data)
result = response.json()

print("Assistant response:", result["choices"][0]["message"]["content"])
```

### Embedding Example

```python
import requests

# Configuration
BASE_URL = "http://localhost:8080"
API_KEY = "your-api-key-here"

headers = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json"
}

# Create embeddings
embedding_data = {
    "model": "text-embedding-ada-002",
    "input": ["Hello world", "Goodbye world"]
}

response = requests.post(f"{BASE_URL}/v1/embeddings", headers=headers, json=embedding_data)
result = response.json()

for i, embedding in enumerate(result["data"]):
    print(f"Text {i+1}: {len(embedding['embedding'])} dimensions")
```

### Streaming Example

```python
import requests
import json

# Configuration
BASE_URL = "http://localhost:8080"
API_KEY = "your-api-key-here"

headers = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json"
}

# Streaming chat completion
chat_data = {
    "model": "llama-3-8b", 
    "messages": [
        {"role": "user", "content": "Tell me a joke"}
    ],
    "stream": True
}

response = requests.post(f"{BASE_URL}/v1/chat/completions", headers=headers, json=chat_data, stream=True)

for line in response.iter_lines():
    if line:
        line = line.decode('utf-8')
        if line.startswith('data: '):
            data = line[6:]  # Remove 'data: ' prefix
            if data == '[DONE]':
                break
            try:
                chunk = json.loads(data)
                if 'choices' in chunk and len(chunk['choices']) > 0:
                    delta = chunk['choices'][0].get('delta', {})
                    if 'content' in delta:
                        print(delta['content'], end='', flush=True)
            except json.JSONDecodeError:
                continue
print()  # New line after completion
```

## Error Handling

### Common Error Responses

**Invalid API Key:**
```json
{
  "detail": "Invalid or expired API key"
}
```

**Model Not Found:**
```json
{
  "detail": "Model 'unknown-model' not found"
}
```

**Server Error:**
```json
{
  "detail": "Error from upstream server: Connection timeout"
}
```

### Error Handling in Python

```python
import requests

def make_api_request(url, headers, data):
    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status()  # Raise exception for HTTP errors
        return response.json()
    except requests.exceptions.HTTPError as e:
        print(f"HTTP Error: {e}")
        print(f"Response: {response.text}")
    except requests.exceptions.ConnectionError:
        print("Connection error - check if gateway is running")
    except requests.exceptions.Timeout:
        print("Request timed out")
    except Exception as e:
        print(f"Unexpected error: {e}")
    return None

# Usage
result = make_api_request(
    f"{BASE_URL}/v1/chat/completions",
    headers,
    {"model": "llama-3-8b", "messages": [{"role": "user", "content": "Hi"}]}
)
```

## Best Practices

### 1. Model Selection
- Always check available models before making requests
- Use the exact model name from the `/v1/models` endpoint
- Some models may be hosted on multiple servers for load balancing

### 2. Performance
- Use streaming for long responses to improve user experience
- Set appropriate `max_tokens` limits to control costs
- Monitor response times and adjust `temperature` as needed

### 3. Error Handling
- Always handle HTTP errors gracefully
- Implement retry logic for transient failures
- Log errors for debugging purposes

### 4. Rate Limiting
- Be mindful of rate limits on upstream servers
- Implement exponential backoff for failed requests
- Monitor usage through your API key statistics

## Quick Reference

| Endpoint | Purpose | Method |
|----------|---------|--------|
| `/v1/models` | List available models | GET |
| `/v1/chat/completions` | Generate text/chat | POST |
| `/v1/embeddings` | Create text embeddings | POST |

### Chat Completion Parameters
- `model` (required): Model name
- `messages` (required): Conversation messages
- `temperature` (optional): 0.0-2.0, randomness
- `max_tokens` (optional): Response length limit
- `stream` (optional): Enable streaming

### Embedding Parameters
- `model` (required): Embedding model name
- `input` (required): Text or array of texts
- `encoding_format` (optional): "float" or "base64"

## Support

For support:
1. Check the admin dashboard at `/admin/dashboard`
2. Verify your API key is valid and active
3. Ensure the model you're trying to use is listed in `/v1/models`
4. Contact your system administrator for gateway issues

## Next Steps

1. Get your API key from your system administrator
2. Test the connection with `/v1/models`
3. Try a simple chat completion
4. Experiment with different models and parameters
5. Implement proper error handling in your application
