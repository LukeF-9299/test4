import time
from typing import Optional
from fastapi import HTTPException, Security, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from database import DatabaseManager, APIKey

security = HTTPBearer(auto_error=False)


class AuthManager:
    def __init__(self, db_manager: DatabaseManager):
        self.db_manager = db_manager
    
    async def verify_api_key(self, credentials: Optional[HTTPAuthorizationCredentials] = Security(security)) -> APIKey:
        """Verify API key and return the key record"""
        if not credentials:
            raise HTTPException(
                status_code=401,
                detail="API key required",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        api_key = credentials.credentials
        key_record = self.db_manager.validate_api_key(api_key)
        
        if not key_record:
            raise HTTPException(
                status_code=401,
                detail="Invalid or expired API key",
                headers={"WWW-Authenticate": "Bearer"},
            )
        
        return key_record
    
    def get_api_key_from_header(self, request: Request) -> Optional[str]:
        """Extract API key from Authorization header"""
        auth_header = request.headers.get("Authorization")
        if not auth_header:
            return None
        
        if auth_header.startswith("Bearer "):
            return auth_header[7:]  # Remove "Bearer " prefix
        
        return None


class RequestLogger:
    def __init__(self, db_manager: DatabaseManager):
        self.db_manager = db_manager
    
    def log_request(self, api_key_id: int, model: str, endpoint: str, status_code: int, 
                   request_size: int = None, response_size: int = None, processing_time_ms: int = None):
        """Log API request for analytics"""
        self.db_manager.log_usage(
            api_key_id=api_key_id,
            model=model,
            endpoint=endpoint,
            status_code=status_code,
            request_size=request_size,
            response_size=response_size,
            processing_time_ms=processing_time_ms
        )


# Global instances (will be initialized in main app)
auth_manager: Optional[AuthManager] = None
request_logger: Optional[RequestLogger] = None


def init_auth(db_manager: DatabaseManager):
    """Initialize authentication system"""
    global auth_manager, request_logger
    auth_manager = AuthManager(db_manager)
    request_logger = RequestLogger(db_manager)


async def get_current_api_key(credentials: Optional[HTTPAuthorizationCredentials] = Security(security)) -> APIKey:
    """FastAPI dependency to get current API key"""
    if not auth_manager:
        raise HTTPException(status_code=500, detail="Authentication not initialized")
    
    return await auth_manager.verify_api_key(credentials)
