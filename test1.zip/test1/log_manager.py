import asyncio
import logging
from datetime import datetime, time
from sqlite_logger import SQLiteLogger

logger = logging.getLogger(__name__)


class LogManager:
    def __init__(self, sqlite_logger: SQLiteLogger):
        self.sqlite_logger = sqlite_logger
        self.running = False
    
    async def daily_dump_scheduler(self):
        """Run daily dump at midnight"""
        self.running = True
        logger.info("Starting daily log dump scheduler")
        
        while self.running:
            try:
                now = datetime.now()
                
                # Check if it's midnight (within 5 minute window)
                if now.hour == 0 and now.minute < 5:
                    logger.info("Running daily log dump")
                    try:
                        dump_file = self.sqlite_logger.create_daily_dump()
                        logger.info(f"Daily dump completed: {dump_file}")
                        
                        # Clean up old dumps (keep 30 days)
                        self.sqlite_logger.cleanup_old_dumps(days_to_keep=30)
                        
                    except Exception as e:
                        logger.error(f"Failed to create daily dump: {e}")
                
                # Wait 1 hour before next check
                await asyncio.sleep(3600)
                
            except Exception as e:
                logger.error(f"Error in daily dump scheduler: {e}")
                await asyncio.sleep(300)  # Wait 5 minutes before retrying
    
    def stop_scheduler(self):
        """Stop the daily dump scheduler"""
        self.running = False
        logger.info("Stopping daily log dump scheduler")
    
    def get_log_info(self):
        """Get information about current logs and dumps"""
        stats = self.sqlite_logger.get_log_stats()
        dumps = self.sqlite_logger.list_dumps()
        
        return {
            "current_stats": stats,
            "available_dumps": dumps,
            "total_dump_files": len(dumps),
            "total_dump_size_mb": sum(dump['size_mb'] for dump in dumps)
        }
