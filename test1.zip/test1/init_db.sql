-- Database initialization script for LLM API Gateway
-- This script runs automatically when the PostgreSQL container starts

-- Create additional indexes for better performance
CREATE INDEX IF NOT EXISTS idx_api_keys_created_at ON api_keys(created_at);
CREATE INDEX IF NOT EXISTS idx_api_keys_last_used_at ON api_keys(last_used_at);
CREATE INDEX IF NOT EXISTS idx_usage_logs_timestamp ON usage_logs(timestamp);
CREATE INDEX IF NOT EXISTS idx_usage_logs_api_key_id ON usage_logs(api_key_id);
CREATE INDEX IF NOT EXISTS idx_usage_logs_model ON usage_logs(model);

-- Indexes for aggregated stats table
CREATE INDEX IF NOT EXISTS idx_aggregated_stats_period_type ON aggregated_stats(period_type);
CREATE INDEX IF NOT EXISTS idx_aggregated_stats_period_start ON aggregated_stats(period_start);
CREATE INDEX IF NOT EXISTS idx_aggregated_stats_period_type_start ON aggregated_stats(period_type, period_start);

-- Create a default admin API key (you should change this after first run)
-- This key will be created by the application, not here, for security
