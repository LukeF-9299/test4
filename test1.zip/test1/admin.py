from datetime import datetime, timedelta
from typing import List, Optional
import json
from pydantic import BaseModel, Field
from fastapi import FastAPI, HTTPException, Depends, Query
from database import DatabaseManager, APIKey
from auth import get_current_api_key, auth_manager


# Pydantic models for API key management
class APIKeyCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = Field(None, max_length=1000)
    expires_in_days: Optional[int] = Field(None, ge=1, le=365)
    created_by: Optional[str] = Field(None, max_length=255)


class APIKeyResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    is_active: bool
    created_at: datetime
    last_used_at: Optional[datetime]
    expires_at: Optional[datetime]
    created_by: Optional[str]


class APIKeyCreateResponse(BaseModel):
    api_key: str  # Only returned once during creation
    key_info: APIKeyResponse


class UsageStatsResponse(BaseModel):
    total_requests: int
    successful_requests: int
    error_rate: float
    model_usage: dict
    endpoint_usage: dict
    period_days: int


class AdminAPI:
    def __init__(self, db_manager: DatabaseManager):
        self.db_manager = db_manager
    
    def register_routes(self, app: FastAPI):
        """Register admin API routes"""
        
        @app.post("/admin/api-keys", response_model=APIKeyCreateResponse)
        async def create_api_key(
            api_key_data: APIKeyCreate,
            current_key: APIKey = Depends(get_current_api_key)
        ):
            """Create a new API key (requires authentication)"""
            try:
                # Calculate expiration date if specified
                expires_at = None
                if api_key_data.expires_in_days:
                    expires_at = datetime.utcnow() + timedelta(days=api_key_data.expires_in_days)
                
                # Create the API key
                api_key, key_hash = self.db_manager.create_api_key(
                    name=api_key_data.name,
                    description=api_key_data.description,
                    expires_at=expires_at,
                    created_by=api_key_data.created_by or f"key_{current_key.id}"
                )
                
                # Get the created key details
                created_key = self.db_manager.validate_api_key(api_key)
                
                return APIKeyCreateResponse(
                    api_key=api_key,
                    key_info=APIKeyResponse(
                        id=created_key.id,
                        name=created_key.name,
                        description=created_key.description,
                        is_active=created_key.is_active,
                        created_at=created_key.created_at,
                        last_used_at=created_key.last_used_at,
                        expires_at=created_key.expires_at,
                        created_by=created_key.created_by
                    )
                )
            
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Failed to create API key: {str(e)}")
        
        @app.get("/admin/api-keys", response_model=List[APIKeyResponse])
        async def list_api_keys(
            include_inactive: bool = Query(False, description="Include inactive API keys"),
            current_key: APIKey = Depends(get_current_api_key)
        ):
            """List all API keys (requires authentication)"""
            try:
                api_keys = self.db_manager.get_api_keys(include_inactive=include_inactive)
                
                return [
                    APIKeyResponse(
                        id=key.id,
                        name=key.name,
                        description=key.description,
                        is_active=key.is_active,
                        created_at=key.created_at,
                        last_used_at=key.last_used_at,
                        expires_at=key.expires_at,
                        created_by=key.created_by
                    )
                    for key in api_keys
                ]
            
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Failed to list API keys: {str(e)}")
        
        @app.post("/admin/api-keys/{key_id}/revoke")
        async def revoke_api_key(
            key_id: int,
            current_key: APIKey = Depends(get_current_api_key)
        ):
            """Revoke an API key (requires authentication)"""
            try:
                success = self.db_manager.revoke_api_key(key_id)
                
                if not success:
                    raise HTTPException(status_code=404, detail="API key not found")
                
                return {"message": f"API key {key_id} has been revoked"}
            
            except HTTPException:
                raise
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Failed to revoke API key: {str(e)}")
        
        @app.get("/admin/usage-stats", response_model=UsageStatsResponse)
        async def get_usage_stats(
            api_key_id: Optional[int] = Query(None, description="Filter by specific API key"),
            days: int = Query(30, ge=1, le=365, description="Number of days to analyze"),
            current_key: APIKey = Depends(get_current_api_key)
        ):
            """Get usage statistics (requires authentication)"""
            try:
                stats = self.db_manager.get_usage_stats(api_key_id=api_key_id, days=days)
                
                return UsageStatsResponse(**stats)
            
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Failed to get usage stats: {str(e)}")
        
        @app.get("/admin/my-usage", response_model=UsageStatsResponse)
        async def get_my_usage_stats(
            days: int = Query(30, ge=1, le=365, description="Number of days to analyze"),
            current_key: APIKey = Depends(get_current_api_key)
        ):
            """Get usage statistics for current API key"""
            try:
                stats = self.db_manager.get_usage_stats(api_key_id=current_key.id, days=days)
                
                return UsageStatsResponse(**stats)
            
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Failed to get usage stats: {str(e)}")
        
        @app.get("/admin/me", response_model=APIKeyResponse)
        async def get_current_key_info(
            current_key: APIKey = Depends(get_current_api_key)
        ):
            """Get information about the current API key"""
            return APIKeyResponse(
                id=current_key.id,
                name=current_key.name,
                description=current_key.description,
                is_active=current_key.is_active,
                created_at=current_key.created_at,
                last_used_at=current_key.last_used_at,
                expires_at=current_key.expires_at,
                created_by=current_key.created_by
            )
        
        @app.get("/admin/logs/info")
        async def get_log_info(
            current_key: APIKey = Depends(get_current_api_key)
        ):
            """Get information about current logs and available dumps"""
            try:
                # Import here to avoid circular imports
                from gateway import gateway
                log_info = gateway.log_manager.get_log_info()
                return log_info
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Failed to get log info: {str(e)}")
        
        @app.post("/admin/logs/dump")
        async def create_manual_dump(
            current_key: APIKey = Depends(get_current_api_key)
        ):
            """Manually create a daily dump"""
            try:
                # Import here to avoid circular imports
                from gateway import gateway
                dump_file = gateway.sqlite_logger.create_daily_dump()
                return {"message": "Manual dump created", "file": dump_file}
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Failed to create dump: {str(e)}")
        
        @app.post("/admin/logs/cleanup")
        async def cleanup_old_logs(
            days_to_keep: int = Query(30, ge=1, le=365),
            current_key: APIKey = Depends(get_current_api_key)
        ):
            """Clean up old log dumps"""
            try:
                # Import here to avoid circular imports
                from gateway import gateway
                gateway.sqlite_logger.cleanup_old_dumps(days_to_keep=days_to_keep)
                return {"message": f"Cleaned up dumps older than {days_to_keep} days"}
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Failed to cleanup logs: {str(e)}")
        
        @app.get("/admin/health-summary")
        async def get_health_summary(
            hours: int = Query(24, ge=1, le=8760, description="Number of hours to analyze"),
            current_key: APIKey = Depends(get_current_api_key)
        ):
            """Get health summary for dashboard"""
            try:
                health_summary = self.db_manager.get_health_summary(hours=hours)
                return health_summary
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Failed to get health summary: {str(e)}")
        
        @app.get("/admin/aggregated-stats")
        async def get_aggregated_stats(
            period_type: str = Query("hour", regex="^(hour|day|month)$"),
            limit: int = Query(100, ge=1, le=1000),
            current_key: APIKey = Depends(get_current_api_key)
        ):
            """Get aggregated statistics"""
            try:
                stats = self.db_manager.get_aggregated_stats(period_type=period_type, limit=limit)
                
                return [
                    {
                        "id": stat.id,
                        "period_type": stat.period_type,
                        "period_start": stat.period_start.isoformat(),
                        "period_end": stat.period_end.isoformat(),
                        "total_requests": stat.total_requests,
                        "successful_requests": stat.successful_requests,
                        "error_requests": stat.error_requests,
                        "avg_response_time_ms": stat.avg_response_time_ms,
                        "min_response_time_ms": stat.min_response_time_ms,
                        "max_response_time_ms": stat.max_response_time_ms,
                        "total_request_bytes": stat.total_request_bytes,
                        "total_response_bytes": stat.total_response_bytes,
                        "model_usage": json.loads(stat.model_usage) if stat.model_usage else {},
                        "endpoint_usage": json.loads(stat.endpoint_usage) if stat.endpoint_usage else {},
                        "error_distribution": json.loads(stat.error_distribution) if stat.error_distribution else {},
                        "created_at": stat.created_at.isoformat()
                    }
                    for stat in stats
                ]
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Failed to get aggregated stats: {str(e)}")
