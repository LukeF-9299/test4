import asyncio
import logging
import time
import uuid
from typing import Dict, List, Optional
import httpx
from fastapi import FastAPI, HTTPException, Request, Response, Depends
from fastapi.responses import StreamingResponse, FileResponse
from fastapi.staticfiles import StaticFiles
import uvicorn
import os

from models import Config, ChatRequest, EmbeddingRequest, ServerConfig
from database import DatabaseManager
from auth import init_auth, get_current_api_key, request_logger
from admin import AdminAPI
from aggregator import StatsAggregator
from sqlite_logger import SQLiteLogger
from log_manager import LogManager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ModelGateway:
    def __init__(self, config_path: str = "config.yaml", database_url: str = None):
        self.config = Config.from_yaml(config_path)
        self.model_to_servers: Dict[str, List[ServerConfig]] = {}
        self.server_load: Dict[str, int] = {}  # Track active requests per server
        # httpx connection pool — keep connections alive to backend servers
        self.client = httpx.AsyncClient(
            timeout=self.config.gateway.request_timeout,
            limits=httpx.Limits(
                max_connections=200,
                max_keepalive_connections=50,
                keepalive_expiry=30,
            ),
        )
        
        # Initialize database
        if database_url is None:
            database_url = os.getenv("DATABASE_URL", "postgresql://user:password@localhost:5432/gateway_db")
        
        self.db_manager = DatabaseManager(database_url)
        self.db_manager.create_tables()
        
        # Initialize authentication
        init_auth(self.db_manager)
        
        # Initialize stats aggregator
        self.aggregator = StatsAggregator(self.db_manager)
        
        # Initialize SQLite logger for full query logging
        self.sqlite_logger = SQLiteLogger()
        
        # Initialize log manager for daily dumps
        self.log_manager = LogManager(self.sqlite_logger)
        
        # Build model to servers mapping (support multiple servers per model)
        for server in self.config.servers:
            self.server_load[server.name] = 0  # Initialize load counter
            for model in server.models:
                if model not in self.model_to_servers:
                    self.model_to_servers[model] = []
                self.model_to_servers[model].append(server)
        
        logger.info(f"Loaded {len(self.config.servers)} servers with {len(self.model_to_servers)} models")
        
        # Log models with multiple servers
        for model, servers in self.model_to_servers.items():
            if len(servers) > 1:
                logger.info(f"Model '{model}' available on {len(servers)} servers: {[s.name for s in servers]}")
    
    async def health_check(self):
        """Check health of all configured servers"""
        results = {}
        for server in self.config.servers:
            try:
                url = f"{server.base_url}{server.health_endpoint}"
                headers = {}
                if server.api_key:
                    headers["Authorization"] = f"Bearer {server.api_key}"
                
                response = await self.client.get(url, headers=headers)
                results[server.name] = "healthy" if response.status_code == 200 else "unhealthy"
            except Exception as e:
                logger.error(f"Health check failed for {server.name}: {e}")
                results[server.name] = "unhealthy"
        
        return results
    
    def _get_least_busy_server(self, model: str) -> ServerConfig:
        """Select the least busy server for a given model"""
        if model not in self.model_to_servers:
            raise HTTPException(status_code=404, detail=f"Model '{model}' not found")
        
        available_servers = self.model_to_servers[model]
        
        # Sort servers by current load (ascending)
        least_busy_server = min(available_servers, key=lambda s: self.server_load[s.name])
        
        logger.debug(f"Selected server {least_busy_server.name} for model {model} (load: {self.server_load[least_busy_server.name]})")
        
        return least_busy_server
    
    async def proxy_request(self, model: str, request_data: dict, stream: bool = False, endpoint: str = "/v1/chat/completions"):
        """Proxy request to the appropriate server using load balancing"""
        server = self._get_least_busy_server(model)
        
        # Increment server load
        self.server_load[server.name] += 1
        
        try:
            # Prepare headers
            headers = {"Content-Type": "application/json"}
            if server.api_key:
                headers["Authorization"] = f"Bearer {server.api_key}"
            
            url = f"{server.base_url}{endpoint}"
            
            if stream:
                return await self._stream_response(server, url, headers, request_data)
            else:
                response = await self.client.post(url, headers=headers, json=request_data)
                response.raise_for_status()
                return response.json()
        
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error from {server.name}: {e}")
            raise HTTPException(status_code=e.response.status_code, detail=f"Error from upstream server: {e.response.text}")
        except Exception as e:
            logger.error(f"Error proxying request to {server.name}: {e}")
            raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")
        finally:
            # Decrement server load when request completes
            self.server_load[server.name] -= 1
    
    def _is_embedding_model(self, model: str) -> bool:
        """Check if model is an embedding model"""
        embedding_keywords = ["embedding", "sentence-transformers", "text-embedding"]
        return any(keyword in model.lower() for keyword in embedding_keywords)
    
    async def _stream_response(self, server: ServerConfig, url: str, headers: dict, request_data: dict):
        """Handle streaming responses"""
        try:
            async with self.client.stream("POST", url, headers=headers, json=request_data) as response:
                response.raise_for_status()
                
                async def generate():
                    try:
                        async for chunk in response.aiter_bytes():
                            yield chunk
                    finally:
                        # Decrement server load when stream completes
                        self.server_load[server.name] -= 1
                
                return StreamingResponse(generate(), media_type="text/event-stream")
        except Exception as e:
            # Decrement server load on error
            self.server_load[server.name] -= 1
            raise e
    
    async def list_models(self):
        """List all available models"""
        models = []
        for model, servers in self.model_to_servers.items():
            server_names = [s.name for s in servers]
            models.append({
                "id": model,
                "object": "model",
                "created": int(time.time()),
                "owned_by": f"{', '.join(server_names)} ({len(servers)} servers)"
            })
        return {"object": "list", "data": models}
    
    async def shutdown(self):
        """Cleanup all resources — flush buffers, close pools."""
        await self.client.aclose()
        self.sqlite_logger.shutdown()
        self.db_manager.shutdown()


# Initialize FastAPI app
gateway = ModelGateway()
app = FastAPI(title="LLM API Gateway", version="1.0.0")

# Register admin API routes
admin_api = AdminAPI(gateway.db_manager)
admin_api.register_routes(app)

@app.on_event("startup")
async def startup_event():
    """Start the stats aggregation and log dump schedulers"""
    import asyncio
    asyncio.create_task(gateway.aggregator.start_scheduler())
    asyncio.create_task(gateway.log_manager.daily_dump_scheduler())


@app.on_event("shutdown")
async def shutdown_event():
    """Shutdown gateway, aggregator, and log manager"""
    gateway.aggregator.stop_scheduler()
    gateway.log_manager.stop_scheduler()
    await gateway.shutdown()


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    results = await gateway.health_check()
    return {"status": "gateway_healthy", "servers": results}


@app.get("/status")
async def server_status():
    """Server load and status endpoint"""
    return {
        "server_load": gateway.server_load,
        "models_per_server": {
            server.name: len(server.models) for server in gateway.config.servers
        },
        "total_requests": sum(gateway.server_load.values())
    }


@app.get("/v1/models")
async def list_models():
    """List available models (OpenAI compatible)"""
    return await gateway.list_models()


@app.post("/v1/chat/completions")
async def chat_completions(
    request: ChatRequest,
    current_key = Depends(get_current_api_key),
    http_request: Request = None
):
    """Chat completions endpoint (OpenAI compatible)"""
    start_time = time.time()
    status_code = 500
    request_size = len(str(request.model_dump()))
    
    # Extract request details for SQLite logging
    request_headers = dict(http_request.headers) if http_request else {}
    request_body = request.model_dump()
    
    try:
        request_data = request.model_dump()
        result = await gateway.proxy_request(
            model=request.model,
            request_data=request_data,
            stream=request.stream or False
        )
        
        if request.stream:
            # For streaming, we'll log when the stream is initiated
            status_code = 200
            processing_time_ms = int((time.time() - start_time) * 1000)
            
            # Log to SQLite (streaming response)
            gateway.sqlite_logger.log_full_query(
                api_key_id=current_key.id,
                api_key_hash=current_key.key_hash,
                model=request.model,
                endpoint="/v1/chat/completions",
                method="POST",
                request_headers=request_headers,
                request_body=request_body,
                response_headers={"content-type": "text/event-stream"},
                response_body={"streaming": True},
                status_code=status_code,
                processing_time_ms=processing_time_ms,
                request_size=request_size,
                user_agent=request_headers.get("user-agent"),
                ip_address=request_headers.get("x-forwarded-for", request_headers.get("x-real-ip"))
            )
            
            if request_logger:
                request_logger.log_request(
                    api_key_id=current_key.id,
                    model=request.model,
                    endpoint="/v1/chat/completions",
                    status_code=status_code,
                    request_size=request_size,
                    processing_time_ms=processing_time_ms
                )
            return result
        else:
            # Ensure response has required OpenAI format fields
            if "id" not in result:
                result["id"] = f"chatcmpl-{uuid.uuid4().hex[:8]}"
            if "created" not in result:
                result["created"] = int(time.time())
            if "object" not in result:
                result["object"] = "chat.completion"
            
            status_code = 200
            response_size = len(str(result))
            processing_time_ms = int((time.time() - start_time) * 1000)
            
            # Get server info for logging
            server = gateway._get_least_busy_server(request.model)
            
            # Log to SQLite (full response)
            gateway.sqlite_logger.log_full_query(
                api_key_id=current_key.id,
                api_key_hash=current_key.key_hash,
                model=request.model,
                endpoint="/v1/chat/completions",
                method="POST",
                request_headers=request_headers,
                request_body=request_body,
                response_headers={"content-type": "application/json"},
                response_body=result,
                status_code=status_code,
                processing_time_ms=processing_time_ms,
                request_size=request_size,
                response_size=response_size,
                server_name=server.name,
                server_url=server.base_url,
                user_agent=request_headers.get("user-agent"),
                ip_address=request_headers.get("x-forwarded-for", request_headers.get("x-real-ip"))
            )
            
            if request_logger:
                request_logger.log_request(
                    api_key_id=current_key.id,
                    model=request.model,
                    endpoint="/v1/chat/completions",
                    status_code=status_code,
                    request_size=request_size,
                    response_size=response_size,
                    processing_time_ms=processing_time_ms
                )
            
            return result
    
    except Exception as e:
        logger.error(f"Error in chat completions: {e}")
        status_code = getattr(e, 'status_code', 500)
        processing_time_ms = int((time.time() - start_time) * 1000)
        
        # Log error to SQLite
        gateway.sqlite_logger.log_full_query(
            api_key_id=current_key.id,
            api_key_hash=current_key.key_hash,
            model=request.model,
            endpoint="/v1/chat/completions",
            method="POST",
            request_headers=request_headers,
            request_body=request_body,
            status_code=status_code,
            processing_time_ms=processing_time_ms,
            request_size=request_size,
            error_message=str(e),
            user_agent=request_headers.get("user-agent"),
            ip_address=request_headers.get("x-forwarded-for", request_headers.get("x-real-ip"))
        )
        
        if request_logger:
            request_logger.log_request(
                api_key_id=current_key.id,
                model=request.model,
                endpoint="/v1/chat/completions",
                status_code=status_code,
                request_size=request_size,
                processing_time_ms=processing_time_ms
            )
        raise


@app.post("/v1/embeddings")
async def create_embeddings(
    request: EmbeddingRequest,
    current_key = Depends(get_current_api_key),
    http_request: Request = None
):
    """Create embeddings endpoint (OpenAI compatible)"""
    start_time = time.time()
    status_code = 500
    request_size = len(str(request.model_dump()))
    
    # Extract request details for SQLite logging
    request_headers = dict(http_request.headers) if http_request else {}
    request_body = request.model_dump()
    
    try:
        request_data = request.model_dump()
        result = await gateway.proxy_request(
            model=request.model,
            request_data=request_data,
            stream=False,
            endpoint="/v1/embeddings"
        )
        
        # Ensure response has required OpenAI format fields
        if "object" not in result:
            result["object"] = "list"
        
        status_code = 200
        response_size = len(str(result))
        processing_time_ms = int((time.time() - start_time) * 1000)
        
        # Get server info for logging
        server = gateway._get_least_busy_server(request.model)
        
        # Log to SQLite (full response)
        gateway.sqlite_logger.log_full_query(
            api_key_id=current_key.id,
            api_key_hash=current_key.key_hash,
            model=request.model,
            endpoint="/v1/embeddings",
            method="POST",
            request_headers=request_headers,
            request_body=request_body,
            response_headers={"content-type": "application/json"},
            response_body=result,
            status_code=status_code,
            processing_time_ms=processing_time_ms,
            request_size=request_size,
            response_size=response_size,
            server_name=server.name,
            server_url=server.base_url,
            user_agent=request_headers.get("user-agent"),
            ip_address=request_headers.get("x-forwarded-for", request_headers.get("x-real-ip"))
        )
        
        if request_logger:
            request_logger.log_request(
                api_key_id=current_key.id,
                model=request.model,
                endpoint="/v1/embeddings",
                status_code=status_code,
                request_size=request_size,
                response_size=response_size,
                processing_time_ms=processing_time_ms
            )
        
        return result
    
    except Exception as e:
        logger.error(f"Error in embeddings: {e}")
        status_code = getattr(e, 'status_code', 500)
        processing_time_ms = int((time.time() - start_time) * 1000)
        
        # Log error to SQLite
        gateway.sqlite_logger.log_full_query(
            api_key_id=current_key.id,
            api_key_hash=current_key.key_hash,
            model=request.model,
            endpoint="/v1/embeddings",
            method="POST",
            request_headers=request_headers,
            request_body=request_body,
            status_code=status_code,
            processing_time_ms=processing_time_ms,
            request_size=request_size,
            error_message=str(e),
            user_agent=request_headers.get("user-agent"),
            ip_address=request_headers.get("x-forwarded-for", request_headers.get("x-real-ip"))
        )
        
        if request_logger:
            request_logger.log_request(
                api_key_id=current_key.id,
                model=request.model,
                endpoint="/v1/embeddings",
                status_code=status_code,
                request_size=request_size,
                processing_time_ms=processing_time_ms
            )
        raise


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "LLM API Gateway",
        "version": "1.0.0",
        "models": len(gateway.model_to_servers),
        "servers": len(gateway.config.servers),
        "authentication": "API key required for all endpoints except /",
        "admin_dashboard": "/admin/dashboard",
        "user_guide": "/user-guide",
        "api_endpoints": {
            "models": "/v1/models",
            "chat": "/v1/chat/completions", 
            "embeddings": "/v1/embeddings"
        }
    }


@app.get("/user-guide")
async def user_guide():
    """User guide endpoint"""
    guide_path = os.path.join(os.path.dirname(__file__), "USER_GUIDE.md")
    if os.path.exists(guide_path):
        return FileResponse(guide_path, media_type="text/markdown")
    else:
        return {
            "message": "User Guide",
            "description": "Comprehensive guide for using the LLM API Gateway",
            "quick_start": {
                "1": "Get your API key from your administrator",
                "2": "List available models: GET /v1/models",
                "3": "Use chat completions: POST /v1/chat/completions",
                "4": "Create embeddings: POST /v1/embeddings"
            },
            "authentication": "Use 'Authorization: Bearer YOUR_API_KEY' header",
            "examples": {
                "list_models": "curl -H 'Authorization: Bearer YOUR_KEY' http://localhost:8080/v1/models",
                "chat": "curl -X POST -H 'Authorization: Bearer YOUR_KEY' -H 'Content-Type: application/json' -d '{\"model\":\"llama-3-8b\",\"messages\":[{\"role\":\"user\",\"content\":\"Hello!\"}]}' http://localhost:8080/v1/chat/completions",
                "embeddings": "curl -X POST -H 'Authorization: Bearer YOUR_KEY' -H 'Content-Type: application/json' -d '{\"model\":\"text-embedding-ada-002\",\"input\":\"Hello world\"}' http://localhost:8080/v1/embeddings"
            },
            "full_documentation": "See USER_GUIDE.md for complete documentation"
        }


@app.get("/admin/dashboard")
async def admin_dashboard():
    """Admin dashboard frontend"""
    dashboard_path = os.path.join(os.path.dirname(__file__), "static", "admin_dashboard.html")
    if os.path.exists(dashboard_path):
        return FileResponse(dashboard_path)
    else:
        raise HTTPException(status_code=404, detail="Dashboard not found")


# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")


if __name__ == "__main__":
    uvicorn.run(
        "gateway:app",
        host=gateway.config.gateway.host,
        port=gateway.config.gateway.port,
        log_level=gateway.config.gateway.log_level,
        loop="uvloop",
        http="httptools",
        workers=1,              # Single process — buffers are not fork-safe
        limit_concurrency=500,  # Max concurrent connections
        backlog=2048,           # TCP listen backlog
        timeout_keep_alive=30,  # Keep-alive timeout
    )
