import asyncio
import logging
from datetime import datetime, timedelta
from database import DatabaseManager, AggregatedStats, UsageLog

logger = logging.getLogger(__name__)


class StatsAggregator:
    def __init__(self, db_manager: DatabaseManager):
        self.db_manager = db_manager
        self.running = False
    
    def _period_exists(self, period_type: str, period_start: datetime) -> bool:
        """Check if aggregated stats already exist for a period (with proper session handling)."""
        db = self.db_manager.get_db()
        try:
            return db.query(AggregatedStats).filter(
                AggregatedStats.period_type == period_type,
                AggregatedStats.period_start == period_start
            ).first() is not None
        finally:
            db.close()
    
    async def aggregate_hourly_stats(self):
        try:
            now = datetime.utcnow()
            hour_start = now.replace(minute=0, second=0, microsecond=0) - timedelta(hours=1)
            hour_end = hour_start + timedelta(hours=1)
            
            if self._period_exists("hour", hour_start):
                return
            
            agg_stats = self.db_manager.aggregate_usage_stats("hour", hour_start, hour_end)
            if agg_stats:
                self.db_manager.save_aggregated_stats(agg_stats)
                logger.info(f"Saved hourly stats: {agg_stats.total_requests} requests")
        except Exception as e:
            logger.error(f"Error in hourly aggregation: {e}")
    
    async def aggregate_daily_stats(self):
        try:
            now = datetime.utcnow()
            day_start = now.replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=1)
            day_end = day_start + timedelta(days=1)
            
            if self._period_exists("day", day_start):
                return
            
            agg_stats = self.db_manager.aggregate_usage_stats("day", day_start, day_end)
            if agg_stats:
                self.db_manager.save_aggregated_stats(agg_stats)
                logger.info(f"Saved daily stats: {agg_stats.total_requests} requests")
        except Exception as e:
            logger.error(f"Error in daily aggregation: {e}")
    
    async def aggregate_monthly_stats(self):
        try:
            now = datetime.utcnow()
            if now.month == 1:
                month_start = datetime(now.year - 1, 12, 1)
            else:
                month_start = datetime(now.year, now.month - 1, 1)
            
            month_end = month_start + timedelta(days=32)
            month_end = month_end.replace(day=1)
            
            if self._period_exists("month", month_start):
                return
            
            agg_stats = self.db_manager.aggregate_usage_stats("month", month_start, month_end)
            if agg_stats:
                self.db_manager.save_aggregated_stats(agg_stats)
                logger.info(f"Saved monthly stats: {agg_stats.total_requests} requests")
        except Exception as e:
            logger.error(f"Error in monthly aggregation: {e}")
    
    async def cleanup_old_logs(self, days_to_keep: int = 7):
        """Clean up old detailed usage logs to save space"""
        db = self.db_manager.get_db()
        try:
            cutoff_date = datetime.utcnow() - timedelta(days=days_to_keep)
            deleted_count = db.query(UsageLog).filter(
                UsageLog.timestamp < cutoff_date
            ).delete()
            db.commit()
            logger.info(f"Cleaned up {deleted_count} old usage log entries")
        except Exception as e:
            logger.error(f"Error in log cleanup: {e}")
        finally:
            db.close()
    
    async def run_aggregation_cycle(self):
        """Run a complete aggregation cycle"""
        logger.info("Starting aggregation cycle")
        
        await self.aggregate_hourly_stats()
        
        # Run daily aggregation at midnight
        now = datetime.utcnow()
        if now.hour == 0 and now.minute < 5:  # Run in first 5 minutes of hour
            await self.aggregate_daily_stats()
            
            # Run monthly aggregation on 1st of month
            if now.day == 1:
                await self.aggregate_monthly_stats()
        
        # Cleanup old logs daily
        if now.hour == 1:  # Run at 1 AM
            await self.cleanup_old_logs()
        
        logger.info("Aggregation cycle completed")
    
    async def start_scheduler(self):
        """Start the aggregation scheduler"""
        self.running = True
        logger.info("Starting stats aggregation scheduler")
        
        while self.running:
            try:
                await self.run_aggregation_cycle()
                
                # Wait for next cycle (run every 5 minutes)
                await asyncio.sleep(300)  # 5 minutes
                
            except Exception as e:
                logger.error(f"Error in aggregation cycle: {e}")
                await asyncio.sleep(60)  # Wait 1 minute before retrying
    
    def stop_scheduler(self):
        """Stop the aggregation scheduler"""
        self.running = False
        logger.info("Stopping stats aggregation scheduler")


async def main():
    """Main function for running the aggregator standalone"""
    import os
    from database import DatabaseManager
    
    database_url = os.getenv("DATABASE_URL", "postgresql://gateway_user:gateway_password@localhost:5432/gateway_db")
    db_manager = DatabaseManager(database_url)
    
    aggregator = StatsAggregator(db_manager)
    
    try:
        await aggregator.start_scheduler()
    except KeyboardInterrupt:
        logger.info("Received interrupt signal")
        aggregator.stop_scheduler()


if __name__ == "__main__":
    asyncio.run(main())
