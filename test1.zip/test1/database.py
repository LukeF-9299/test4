from sqlalchemy import create_engine, Column, String, Integer, DateTime, Boolean, Text, BigInteger, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import QueuePool
from sqlalchemy.sql import func
import os
import json
from datetime import datetime, timedelta
from typing import Dict
from collections import deque
import secrets
import hashlib
import threading
import time as _time
import logging

logger = logging.getLogger(__name__)

# Batched usage log settings
USAGE_FLUSH_INTERVAL = 10   # seconds
USAGE_FLUSH_THRESHOLD = 200  # rows

# API key cache TTL
API_KEY_CACHE_TTL = 300  # seconds (5 min)

Base = declarative_base()


class APIKey(Base):
    __tablename__ = "api_keys"
    
    id = Column(Integer, primary_key=True, index=True)
    key_hash = Column(String(64), unique=True, index=True, nullable=False)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    last_used_at = Column(DateTime(timezone=True), nullable=True)
    expires_at = Column(DateTime(timezone=True), nullable=True)
    created_by = Column(String(255), nullable=True)
    
    def __repr__(self):
        return f"<APIKey(name='{self.name}', active={self.is_active})>"


class UsageLog(Base):
    __tablename__ = "usage_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    api_key_id = Column(Integer, nullable=False)
    model = Column(String(255), nullable=False)
    endpoint = Column(String(255), nullable=False)
    request_size = Column(Integer, nullable=True)
    response_size = Column(Integer, nullable=True)
    status_code = Column(Integer, nullable=False)
    timestamp = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    processing_time_ms = Column(Integer, nullable=True)
    
    def __repr__(self):
        return f"<UsageLog(model='{self.model}', endpoint='{self.endpoint}', status={self.status_code})>"


class AggregatedStats(Base):
    __tablename__ = "aggregated_stats"
    
    id = Column(Integer, primary_key=True, index=True)
    period_type = Column(String(20), nullable=False)  # 'hour', 'day', 'month'
    period_start = Column(DateTime(timezone=True), nullable=False, index=True)
    period_end = Column(DateTime(timezone=True), nullable=False)
    
    # Request counts
    total_requests = Column(Integer, default=0, nullable=False)
    successful_requests = Column(Integer, default=0, nullable=False)
    error_requests = Column(Integer, default=0, nullable=False)
    
    # Performance metrics
    avg_response_time_ms = Column(Integer, nullable=True)
    min_response_time_ms = Column(Integer, nullable=True)
    max_response_time_ms = Column(Integer, nullable=True)
    
    # Data transfer
    total_request_bytes = Column(BigInteger, default=0, nullable=False)
    total_response_bytes = Column(BigInteger, default=0, nullable=False)
    
    # Model-specific stats (JSON)
    model_usage = Column(Text, nullable=True)  # JSON string
    endpoint_usage = Column(Text, nullable=True)  # JSON string
    error_distribution = Column(Text, nullable=True)  # JSON string
    
    # Server health stats
    server_health = Column(Text, nullable=True)  # JSON string with server availability
    
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    
    def __repr__(self):
        return f"<AggregatedStats(period='{self.period_type}', start='{self.period_start}', requests={self.total_requests})>"


class DatabaseManager:
    def __init__(self, database_url: str = "postgresql://user:password@localhost:5432/gateway_db"):
        self.database_url = database_url
        self.engine = create_engine(
            self.database_url,
            poolclass=QueuePool,
            pool_size=20,
            max_overflow=40,
            pool_timeout=30,
            pool_recycle=1800,
            pool_pre_ping=True,
        )
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
        
        # ---- In-memory API key cache ----
        # { key_hash: (APIKey-like dict, cached_at_timestamp) }
        self._key_cache: Dict = {}
        self._key_cache_lock = threading.Lock()
        
        # ---- Batched usage log buffer ----
        self._usage_buffer: deque = deque()
        self._usage_lock = threading.Lock()
        self._usage_running = True
        self._usage_thread = threading.Thread(target=self._usage_flush_loop, daemon=True)
        
        # Expose ORM classes for aggregator
        self.AggregatedStats = AggregatedStats
        self.UsageLog = UsageLog
        
    def create_tables(self):
        """Create all database tables"""
        Base.metadata.create_all(bind=self.engine)
        # Start the usage flush thread after tables exist
        if not self._usage_thread.is_alive():
            self._usage_thread.start()
        
    def get_db(self) -> Session:
        """Get database session — caller MUST close it."""
        return self.SessionLocal()
    
    # ------------------------------------------------------------------
    # API key helpers
    # ------------------------------------------------------------------

    def generate_api_key(self) -> str:
        return f"gw-{secrets.token_urlsafe(32)}"
    
    def hash_api_key(self, api_key: str) -> str:
        return hashlib.sha256(api_key.encode()).hexdigest()
    
    def create_api_key(self, name: str, description: str = None, expires_at: datetime = None, created_by: str = None) -> tuple[str, str]:
        db = self.get_db()
        try:
            api_key = self.generate_api_key()
            key_hash = self.hash_api_key(api_key)
            db_key = APIKey(
                key_hash=key_hash, name=name,
                description=description, expires_at=expires_at,
                created_by=created_by,
            )
            db.add(db_key)
            db.commit()
            db.refresh(db_key)
            # Warm cache
            self._cache_key(db_key)
            return api_key, key_hash
        finally:
            db.close()
    
    # ------------------------------------------------------------------
    # API key validation with in-memory cache
    # ------------------------------------------------------------------

    def _cache_key(self, db_key: APIKey):
        """Store an APIKey object in the local cache."""
        with self._key_cache_lock:
            self._key_cache[db_key.key_hash] = (db_key, _time.time())

    def validate_api_key(self, api_key: str) -> APIKey:
        if not api_key:
            return None
        
        key_hash = self.hash_api_key(api_key)
        
        # 1. Check cache
        with self._key_cache_lock:
            cached = self._key_cache.get(key_hash)
            if cached:
                db_key, cached_at = cached
                if _time.time() - cached_at < API_KEY_CACHE_TTL:
                    if db_key.is_active and (not db_key.expires_at or db_key.expires_at >= datetime.utcnow()):
                        return db_key
                    else:
                        # Expired or deactivated — evict
                        del self._key_cache[key_hash]
                        return None
                else:
                    # Stale — fall through to DB
                    del self._key_cache[key_hash]
        
        # 2. DB lookup (no write on every request — last_used updated in batch)
        db = self.get_db()
        try:
            db_key = db.query(APIKey).filter(
                APIKey.key_hash == key_hash,
                APIKey.is_active == True
            ).first()
            
            if not db_key:
                return None
            if db_key.expires_at and db_key.expires_at < datetime.utcnow():
                return None
            
            # Cache it
            self._cache_key(db_key)
            return db_key
        finally:
            db.close()

    def invalidate_key_cache(self, key_hash: str = None):
        """Invalidate one or all cached keys."""
        with self._key_cache_lock:
            if key_hash:
                self._key_cache.pop(key_hash, None)
            else:
                self._key_cache.clear()
    
    # ------------------------------------------------------------------
    # Batched usage logging
    # ------------------------------------------------------------------

    def log_usage(self, api_key_id: int, model: str, endpoint: str, status_code: int,
                  request_size: int = None, response_size: int = None, processing_time_ms: int = None):
        """Append a usage record to the in-memory buffer (non-blocking)."""
        row = {
            "api_key_id": api_key_id, "model": model, "endpoint": endpoint,
            "status_code": status_code, "request_size": request_size,
            "response_size": response_size, "processing_time_ms": processing_time_ms,
            "timestamp": datetime.utcnow(),
        }
        with self._usage_lock:
            self._usage_buffer.append(row)
            buf_len = len(self._usage_buffer)
        
        if buf_len >= USAGE_FLUSH_THRESHOLD:
            self._flush_usage_buffer()

    def _flush_usage_buffer(self):
        with self._usage_lock:
            if not self._usage_buffer:
                return
            batch = list(self._usage_buffer)
            self._usage_buffer.clear()
        
        db = self.get_db()
        try:
            db.execute(
                UsageLog.__table__.insert(),
                batch,
            )
            db.commit()
        except Exception as e:
            logger.error(f"Failed to flush {len(batch)} usage logs: {e}")
            # Re-queue so data isn't lost
            with self._usage_lock:
                self._usage_buffer.extendleft(reversed(batch))
        finally:
            db.close()

    def _usage_flush_loop(self):
        while self._usage_running:
            _time.sleep(USAGE_FLUSH_INTERVAL)
            try:
                self._flush_usage_buffer()
            except Exception as e:
                logger.error(f"Usage flush loop error: {e}")
    
    # ------------------------------------------------------------------
    # Admin / read-only helpers (unchanged logic, pooled sessions)
    # ------------------------------------------------------------------
    
    def get_api_keys(self, include_inactive: bool = False) -> list[APIKey]:
        db = self.get_db()
        try:
            query = db.query(APIKey)
            if not include_inactive:
                query = query.filter(APIKey.is_active == True)
            return query.all()
        finally:
            db.close()
    
    def revoke_api_key(self, key_id: int) -> bool:
        db = self.get_db()
        try:
            db_key = db.query(APIKey).filter(APIKey.id == key_id).first()
            if db_key:
                db_key.is_active = False
                db.commit()
                self.invalidate_key_cache(db_key.key_hash)
                return True
            return False
        finally:
            db.close()
    
    def get_usage_stats(self, api_key_id: int = None, days: int = 30) -> dict:
        """Get usage statistics using SQL aggregation (not Python)."""
        db = self.get_db()
        try:
            since_date = datetime.utcnow() - timedelta(days=days)
            
            # Use SQL COUNT/SUM instead of loading all rows
            base_filter = "WHERE timestamp >= :since"
            params: dict = {"since": since_date}
            if api_key_id:
                base_filter += " AND api_key_id = :kid"
                params["kid"] = api_key_id
            
            row = db.execute(text(f"""
                SELECT
                    COUNT(*)                                          AS total,
                    SUM(CASE WHEN status_code >= 200 AND status_code < 300 THEN 1 ELSE 0 END) AS success
                FROM usage_logs {base_filter}
            """), params).fetchone()
            
            total_requests = row[0] or 0
            successful_requests = row[1] or 0
            error_rate = (total_requests - successful_requests) / total_requests if total_requests > 0 else 0
            
            # Model usage
            model_rows = db.execute(text(f"""
                SELECT model, COUNT(*) AS cnt FROM usage_logs {base_filter} GROUP BY model ORDER BY cnt DESC
            """), params).fetchall()
            model_usage = {r[0]: r[1] for r in model_rows}
            
            # Endpoint usage
            ep_rows = db.execute(text(f"""
                SELECT endpoint, COUNT(*) AS cnt FROM usage_logs {base_filter} GROUP BY endpoint ORDER BY cnt DESC
            """), params).fetchall()
            endpoint_usage = {r[0]: r[1] for r in ep_rows}
            
            return {
                "total_requests": total_requests,
                "successful_requests": successful_requests,
                "error_rate": error_rate,
                "model_usage": model_usage,
                "endpoint_usage": endpoint_usage,
                "period_days": days,
            }
        finally:
            db.close()
    
    # ------------------------------------------------------------------
    # Aggregation — SQL-level, never loads all rows into Python
    # ------------------------------------------------------------------

    def aggregate_usage_stats(self, period_type: str, start_time: datetime, end_time: datetime) -> AggregatedStats:
        db = self.get_db()
        try:
            params = {"start": start_time, "end": end_time}
            
            # Core counts
            row = db.execute(text("""
                SELECT
                    COUNT(*)                                          AS total,
                    SUM(CASE WHEN status_code >= 200 AND status_code < 300 THEN 1 ELSE 0 END) AS success,
                    AVG(processing_time_ms)   AS avg_ms,
                    MIN(processing_time_ms)   AS min_ms,
                    MAX(processing_time_ms)   AS max_ms,
                    COALESCE(SUM(request_size), 0)  AS req_bytes,
                    COALESCE(SUM(response_size), 0) AS res_bytes
                FROM usage_logs
                WHERE timestamp >= :start AND timestamp < :end
            """), params).fetchone()
            
            total = row[0] or 0
            if total == 0:
                return None
            
            success = row[1] or 0
            
            # Model usage
            model_rows = db.execute(text("""
                SELECT model, COUNT(*) FROM usage_logs
                WHERE timestamp >= :start AND timestamp < :end GROUP BY model
            """), params).fetchall()
            model_usage = {r[0]: r[1] for r in model_rows}
            
            # Endpoint usage
            ep_rows = db.execute(text("""
                SELECT endpoint, COUNT(*) FROM usage_logs
                WHERE timestamp >= :start AND timestamp < :end GROUP BY endpoint
            """), params).fetchall()
            endpoint_usage = {r[0]: r[1] for r in ep_rows}
            
            # Error distribution
            err_rows = db.execute(text("""
                SELECT status_code, COUNT(*) FROM usage_logs
                WHERE timestamp >= :start AND timestamp < :end AND status_code >= 400
                GROUP BY status_code
            """), params).fetchall()
            error_distribution = {str(r[0]): r[1] for r in err_rows}
            
            return AggregatedStats(
                period_type=period_type, period_start=start_time, period_end=end_time,
                total_requests=total, successful_requests=success, error_requests=total - success,
                avg_response_time_ms=int(row[2]) if row[2] else None,
                min_response_time_ms=row[3], max_response_time_ms=row[4],
                total_request_bytes=row[5], total_response_bytes=row[6],
                model_usage=json.dumps(model_usage),
                endpoint_usage=json.dumps(endpoint_usage),
                error_distribution=json.dumps(error_distribution),
            )
        finally:
            db.close()
    
    def save_aggregated_stats(self, agg_stats: AggregatedStats):
        db = self.get_db()
        try:
            db.add(agg_stats)
            db.commit()
        finally:
            db.close()
    
    def get_aggregated_stats(self, period_type: str, limit: int = 100) -> list[AggregatedStats]:
        db = self.get_db()
        try:
            return db.query(AggregatedStats).filter(
                AggregatedStats.period_type == period_type
            ).order_by(AggregatedStats.period_start.desc()).limit(limit).all()
        finally:
            db.close()
    
    def get_health_summary(self, hours: int = 24) -> dict:
        db = self.get_db()
        try:
            since_time = datetime.utcnow() - timedelta(hours=hours)
            recent_stats = db.query(AggregatedStats).filter(
                AggregatedStats.period_start >= since_time
            ).order_by(AggregatedStats.period_start.desc()).all()
            
            if not recent_stats:
                return {
                    "total_requests": 0, "success_rate": 100.0,
                    "avg_response_time_ms": 0, "error_rate": 0.0,
                    "period_hours": hours, "hourly_stats": [],
                }
            
            total_requests = sum(s.total_requests for s in recent_stats)
            total_successful = sum(s.successful_requests for s in recent_stats)
            success_rate = (total_successful / total_requests * 100) if total_requests > 0 else 100.0
            
            avg_times = [s.avg_response_time_ms for s in recent_stats if s.avg_response_time_ms]
            overall_avg_time = sum(avg_times) // len(avg_times) if avg_times else 0
            
            hourly_stats = []
            for stat in recent_stats:
                hourly_stats.append({
                    "period_start": stat.period_start.isoformat(),
                    "period_end": stat.period_end.isoformat(),
                    "total_requests": stat.total_requests,
                    "successful_requests": stat.successful_requests,
                    "error_requests": stat.error_requests,
                    "success_rate": (stat.successful_requests / stat.total_requests * 100) if stat.total_requests > 0 else 100.0,
                    "avg_response_time_ms": stat.avg_response_time_ms,
                    "model_usage": json.loads(stat.model_usage) if stat.model_usage else {},
                    "error_distribution": json.loads(stat.error_distribution) if stat.error_distribution else {},
                })
            
            return {
                "total_requests": total_requests, "success_rate": success_rate,
                "avg_response_time_ms": overall_avg_time,
                "error_rate": 100.0 - success_rate,
                "period_hours": hours, "hourly_stats": hourly_stats,
            }
        finally:
            db.close()
    
    def shutdown(self):
        """Flush remaining usage logs and dispose connection pool."""
        self._usage_running = False
        self._flush_usage_buffer()
        self.engine.dispose()
