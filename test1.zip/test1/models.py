from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any, Union
import yaml


class ServerConfig(BaseModel):
    name: str
    host: str
    port: int
    models: List[str]
    health_endpoint: str = "/health"
    api_key: Optional[str] = None
    ssl: bool = False

    @property
    def base_url(self) -> str:
        protocol = "https" if self.ssl else "http"
        return f"{protocol}://{self.host}:{self.port}"


class GatewayConfig(BaseModel):
    host: str = "0.0.0.0"
    port: int = 8080
    log_level: str = "info"
    request_timeout: int = 300
    max_retries: int = 3


class Config(BaseModel):
    servers: List[ServerConfig]
    gateway: GatewayConfig = GatewayConfig()

    @classmethod
    def from_yaml(cls, file_path: str) -> "Config":
        with open(file_path, "r") as f:
            data = yaml.safe_load(f)
        return cls(**data)


class ChatRequest(BaseModel):
    model: str
    messages: List[Dict[str, Any]]
    temperature: Optional[float] = 1.0
    max_tokens: Optional[int] = None
    stream: Optional[bool] = False


class ChatCompletionResponse(BaseModel):
    id: str
    object: str = "chat.completion"
    created: int
    model: str
    choices: List[Dict[str, Any]]
    usage: Optional[Dict[str, Any]] = None


class EmbeddingRequest(BaseModel):
    model: str
    input: Union[str, List[str]]
    encoding_format: Optional[str] = "float"


class EmbeddingResponse(BaseModel):
    object: str = "list"
    data: List[Dict[str, Any]]
    model: str
    usage: Optional[Dict[str, Any]] = None
