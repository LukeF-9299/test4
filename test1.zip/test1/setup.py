#!/usr/bin/env python3
"""
Setup script for LLM API Gateway
Creates initial database tables and admin API key
"""

import os
import sys
from database import DatabaseManager

def main():
    # Database configuration
    database_url = os.getenv("DATABASE_URL", "postgresql://gateway_user:gateway_password@localhost:5432/gateway_db")
    
    print("Setting up LLM API Gateway...")
    print(f"Database URL: {database_url}")
    
    try:
        # Initialize database
        db_manager = DatabaseManager(database_url)
        db_manager.create_tables()
        print("Database tables created successfully.")
        
        # Create initial admin API key
        api_key, key_hash = db_manager.create_api_key(
            name="Admin Key",
            description="Default admin API key - change this after setup",
            created_by="setup_script"
        )
        
        print(f"\nAdmin API Key Created: {api_key}")
        print("IMPORTANT: Save this key securely. You'll need it to access the gateway.")
        print("You can create additional API keys using the admin endpoints.")
        
        print(f"\nGateway setup complete!")
        print("Next steps:")
        print("1. Start PostgreSQL: docker-compose up -d")
        print("2. Start the gateway: python gateway.py")
        print("3. Use the admin API key to test: curl -H 'Authorization: Bearer YOUR_API_KEY' http://localhost:8080/")
        
    except Exception as e:
        print(f"Setup failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
