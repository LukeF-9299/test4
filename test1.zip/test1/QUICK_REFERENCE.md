# LLM API Gateway - Quick Reference

## Base URL
```
http://your-gateway-host:8080
```

## Authentication
All requests require:
```
Authorization: Bearer YOUR_API_KEY
```

## Available Endpoints

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/v1/models` | List all available models |
| POST | `/v1/chat/completions` | Chat with LLM models |
| POST | `/v1/embeddings` | Create text embeddings |

## Quick Start

### 1. List Models
```bash
curl -H "Authorization: Bearer YOUR_API_KEY" \
  http://localhost:8080/v1/models
```

### 2. Chat Completion
```bash
curl -X POST http://localhost:8080/v1/chat/completions \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "llama-3-8b",
    "messages": [{"role": "user", "content": "Hello!"}]
  }'
```

### 3. Text Embeddings
```bash
curl -X POST http://localhost:8080/v1/embeddings \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "text-embedding-ada-002",
    "input": "Hello world"
  }'
```

## Request Parameters

### Chat Completions (`/v1/chat/completions`)
- `model` (required): Model name
- `messages` (required): Array of message objects
- `temperature` (optional): 0.0-2.0, default 1.0
- `max_tokens` (optional): Response length limit
- `stream` (optional): Enable streaming, default false

### Embeddings (`/v1/embeddings`)
- `model` (required): Embedding model name
- `input` (required): Text string or array of texts
- `encoding_format` (optional): "float" or "base64"

## Python Examples

### Chat Completion
```python
import requests

headers = {
    "Authorization": "Bearer YOUR_API_KEY",
    "Content-Type": "application/json"
}

response = requests.post(
    "http://localhost:8080/v1/chat/completions",
    headers=headers,
    json={
        "model": "llama-3-8b",
        "messages": [{"role": "user", "content": "Hello!"}]
    }
)

result = response.json()
print(result["choices"][0]["message"]["content"])
```

### Embeddings
```python
import requests

headers = {
    "Authorization": "Bearer YOUR_API_KEY", 
    "Content-Type": "application/json"
}

response = requests.post(
    "http://localhost:8080/v1/embeddings",
    headers=headers,
    json={
        "model": "text-embedding-ada-002",
        "input": "Hello world"
    }
)

result = response.json()
embeddings = result["data"][0]["embedding"]
print(f"Embedding dimensions: {len(embeddings)}")
```

## Response Formats

### Chat Completion Response
```json
{
  "id": "chatcmpl-abc123",
  "object": "chat.completion",
  "created": 1640995200,
  "model": "llama-3-8b",
  "choices": [{
    "index": 0,
    "message": {
      "role": "assistant",
      "content": "Hello! How can I help you?"
    },
    "finish_reason": "stop"
  }],
  "usage": {
    "prompt_tokens": 10,
    "completion_tokens": 15,
    "total_tokens": 25
  }
}
```

### Embeddings Response
```json
{
  "object": "list",
  "data": [{
    "object": "embedding",
    "index": 0,
    "embedding": [0.0023, -0.0017, 0.0045, ...]
  }],
  "model": "text-embedding-ada-002",
  "usage": {
    "prompt_tokens": 3,
    "total_tokens": 3
  }
}
```

## Error Handling

Common HTTP status codes:
- `200`: Success
- `401`: Invalid API key
- `404`: Model not found
- `500`: Server error

Always check the response status and handle errors appropriately.

## Support
- Full documentation: `/user-guide`
- Admin dashboard: `/admin/dashboard`
- Health check: `/health`

## Tips
1. Always check `/v1/models` for available models
2. Use exact model names from the models list
3. Implement proper error handling
4. Monitor response times and usage
5. Use streaming for long responses
