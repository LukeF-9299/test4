# LLM API Gateway

A lightweight API gateway that proxies requests to multiple LLM model servers, configured via a YAML file.

## Features

- **Multi-server support**: Configure multiple LLM providers (OpenAI, Anthropic, local servers)
- **OpenAI-compatible API**: Standard `/v1/chat/completions` and `/v1/models` endpoints
- **Streaming support**: Handle streaming responses from upstream servers
- **Health checks**: Monitor the health of configured servers
- **Automatic format conversion**: Convert between OpenAI and Anthropic API formats
- **Easy configuration**: Simple YAML-based configuration

## Quick Start

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Start PostgreSQL database:
```bash
docker-compose up -d
```

3. Setup the database and create admin API key:
```bash
python setup.py
```

4. Configure your servers in `config.yaml` (update with your actual server IPs):
```yaml
servers:
  - name: "llm-server-1"
    host: "15.1.15.1"
    port: 8000
    models:
      - "llama-3-8b"
      - "llama-3-70b"
    api_key: null
```

5. Start the gateway:
```bash
python gateway.py
```

The gateway will be available at `http://localhost:8080` with API key authentication required.

## API Endpoints

### Chat Completions
```
POST /v1/chat/completions
```

OpenAI-compatible chat completions endpoint. The gateway automatically routes requests to the appropriate server based on the `model` parameter.

### List Models
```
GET /v1/models
```

Returns a list of all available models from all configured servers.

### Health Check
```
GET /health
```

Returns the health status of the gateway and all configured servers.

### Root
```
GET /
```

Basic gateway information.

### Admin API (Requires API Key Authentication)

#### Create API Key
```
POST /admin/api-keys
```
Create a new API key for authentication.

#### List API Keys
```
GET /admin/api-keys
```
List all API keys (requires authentication).

#### Revoke API Key
```
POST /admin/api-keys/{key_id}/revoke
```
Revoke an API key.

#### Usage Statistics
```
GET /admin/usage-stats
```
Get usage statistics for all API keys.

#### My Usage
```
GET /admin/my-usage
```
Get usage statistics for current API key.

#### Health Summary
```
GET /admin/health-summary?hours=24
```
Get health summary for dashboard (hourly, daily, weekly, monthly stats).

#### Aggregated Statistics
```
GET /admin/aggregated-stats?period_type=hour&limit=100
```
Get aggregated statistics for analysis.

## Admin Dashboard

The gateway includes a web-based admin dashboard for monitoring system health and usage statistics:

**Access**: `http://localhost:8080/admin/dashboard`

**Features**:
- **Real-time Metrics**: Total requests, success rate, response time, error rate
- **Time Periods**: View data for last hour, 24 hours, week, month, or all time
- **Interactive Charts**: Request volume trends, error distribution, response time patterns
- **Model Usage**: See which models are most popular and their usage distribution
- **Auto-refresh**: Dashboard updates every 30 seconds automatically

**Dashboard Data**: Only aggregated statistics are stored, not individual queries, making it suitable for high-volume systems (millions of queries per week).

## Full Query Logging

The gateway maintains comprehensive SQLite logs of all queries for audit and analysis purposes:

**SQLite Database**: Stores complete query details including:
- Full request headers and body content
- Complete response data (non-streaming)
- API key information (hashed for security)
- Processing times and data sizes
- Server routing information
- Error details and stack traces
- User agent and IP addresses

**Daily Dump System**:
- Automatic daily backup at midnight
- Compressed SQLite files (`.gz` format)
- Filename format: `full_logs_YYYY-MM-DD.db.gz`
- Stored in `logs/` directory
- Automatic cleanup of old dumps (30 days retention)

**Log Management API**:
- `GET /admin/logs/info` - View current log statistics and available dumps
- `POST /admin/logs/dump` - Create manual daily dump
- `POST /admin/logs/cleanup?days_to_keep=30` - Clean up old dumps

**Storage Efficiency**:
- Current logs stored in `logs/current_logs.db`
- Daily dumps compressed to save space
- Suitable for millions of queries per week
- Easy to process with external tools

**Example Log Query**:
```bash
# View current log statistics
curl -H "Authorization: Bearer YOUR_API_KEY" \
  http://localhost:8080/admin/logs/info

# Create manual dump
curl -X POST -H "Authorization: Bearer YOUR_API_KEY" \
  http://localhost:8080/admin/logs/dump
```

## API Key Authentication

All API endpoints (except `/`) require authentication using a Bearer token:

```bash
curl -H "Authorization: Bearer YOUR_API_KEY" \
  http://localhost:8080/v1/models
```

### Creating API Keys

1. Use the setup script to create the initial admin key:
```bash
python setup.py
```

2. Or create additional keys using the admin API:
```bash
curl -X POST http://localhost:8080/admin/api-keys \
  -H "Authorization: Bearer ADMIN_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "My Application",
    "description": "API key for my app",
    "expires_in_days": 90
  }'
```

## Configuration

Edit `config.yaml` to configure your model servers:

```yaml
servers:
  - name: "server-name"
    host: "hostname"
    port: 8000
    ssl: false  # Set to true for HTTPS
    models:
      - "model-name-1"
      - "model-name-2"
    health_endpoint: "/health"
    api_key: "optional-api-key"

gateway:
  host: "0.0.0.0"
  port: 8080
  log_level: "info"
  request_timeout: 300
  max_retries: 3
```

### Server Configuration Fields

- `name`: Unique identifier for the server
- `host`: Server hostname or IP address
- `port`: Server port
- `ssl`: Whether to use HTTPS
- `models`: List of available models on this server
- `health_endpoint`: Health check endpoint path
- `api_key`: Optional API key for authentication

### Gateway Configuration Fields

- `host`: Gateway bind address
- `port`: Gateway port
- `log_level`: Logging level (debug, info, warning, error)
- `request_timeout`: Request timeout in seconds
- `max_retries`: Maximum retry attempts

## Usage Examples

### Using curl

```bash
# List available models
curl http://localhost:8080/v1/models

# Chat completion
curl -X POST http://localhost:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-3.5-turbo",
    "messages": [{"role": "user", "content": "Hello!"}]
  }'
```

### Using Python

```python
import requests

# List models
response = requests.get("http://localhost:8080/v1/models")
print(response.json())

# Chat completion
response = requests.post(
    "http://localhost:8080/v1/chat/completions",
    json={
        "model": "gpt-3.5-turbo",
        "messages": [{"role": "user", "content": "Hello!"}]
    }
)
print(response.json())
```

## Supported Providers

The gateway supports any LLM provider with an OpenAI-compatible API, including:

- **OpenAI**: GPT models
- **Anthropic**: Claude models (with automatic format conversion)
- **Local servers**: vLLM, Ollama, or any OpenAI-compatible server
- **Custom providers**: Any server implementing the OpenAI API format

## Architecture

```
Client -> Gateway -> Model Server
```

The gateway:
1. Reads configuration from `config.yaml`
2. Maps models to their respective servers
3. Proxies requests to the appropriate server
4. Handles authentication and format conversion
5. Returns responses in OpenAI-compatible format

## Development

To run with auto-reload during development:

```bash
uvicorn gateway:app --reload --host 0.0.0.0 --port 8080
```

## License

MIT License
