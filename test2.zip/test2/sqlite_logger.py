import sqlite3
import json
import os
import shutil
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List, Tuple
from collections import deque
import logging
import gzip
import threading
import time as _time

logger = logging.getLogger(__name__)

# Buffer settings
FLUSH_INTERVAL_SECONDS = 5      # Flush buffer every N seconds
FLUSH_THRESHOLD = 500           # Flush when buffer reaches N items


class SQLiteLogger:
    def __init__(self, logs_dir: str = "logs"):
        self.logs_dir = logs_dir
        self.current_db_path = os.path.join(logs_dir, "current_logs.db")
        
        # In-memory write buffer and lock
        self._buffer: deque = deque()
        self._buffer_lock = threading.Lock()
        
        # Persistent connection for the flush thread (SQLite in WAL mode)
        self._conn: Optional[sqlite3.Connection] = None
        
        # Create logs directory if it doesn't exist
        os.makedirs(logs_dir, exist_ok=True)
        
        # Initialize current database
        self.init_database()
        
        # Start background flush thread
        self._running = True
        self._flush_thread = threading.Thread(target=self._flush_loop, daemon=True)
        self._flush_thread.start()
        
    def init_database(self):
        """Initialize the SQLite database with WAL mode for concurrent reads/writes"""
        conn = sqlite3.connect(self.current_db_path)
        cursor = conn.cursor()
        
        # WAL mode allows concurrent readers while writing
        cursor.execute('PRAGMA journal_mode=WAL')
        # Reduce fsync calls — we can tolerate losing a few seconds of logs on crash
        cursor.execute('PRAGMA synchronous=NORMAL')
        # 64 MB page cache
        cursor.execute('PRAGMA cache_size=-65536')
        # Store temp tables in memory
        cursor.execute('PRAGMA temp_store=MEMORY')
        # Increase WAL autocheckpoint threshold
        cursor.execute('PRAGMA wal_autocheckpoint=10000')
        
        # Create full query logs table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS full_query_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                api_key_id INTEGER,
                api_key_hash TEXT,
                model_name TEXT NOT NULL,
                endpoint TEXT NOT NULL,
                method TEXT NOT NULL,
                request_headers TEXT,
                request_body TEXT,
                response_headers TEXT,
                response_body TEXT,
                status_code INTEGER,
                processing_time_ms INTEGER,
                request_size INTEGER,
                response_size INTEGER,
                server_name TEXT,
                server_url TEXT,
                error_message TEXT,
                user_agent TEXT,
                ip_address TEXT
            )
        ''')
        
        # Minimal indexes - keep writes fast; this DB is dumped daily and
        # queried very rarely on this server
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_full_logs_timestamp ON full_query_logs(timestamp)')
        
        conn.commit()
        conn.close()
        logger.info(f"SQLite logger initialized at {self.current_db_path} (WAL mode)")
    
    # ------------------------------------------------------------------
    # Write buffer
    # ------------------------------------------------------------------

    def log_full_query(self, 
                      api_key_id: int,
                      api_key_hash: str,
                      model: str,
                      endpoint: str,
                      method: str,
                      request_headers: Dict[str, Any],
                      request_body: Dict[str, Any],
                      response_headers: Optional[Dict[str, Any]] = None,
                      response_body: Optional[Dict[str, Any]] = None,
                      status_code: Optional[int] = None,
                      processing_time_ms: Optional[int] = None,
                      request_size: Optional[int] = None,
                      response_size: Optional[int] = None,
                      server_name: Optional[str] = None,
                      server_url: Optional[str] = None,
                      error_message: Optional[str] = None,
                      user_agent: Optional[str] = None,
                      ip_address: Optional[str] = None):
        """Append a log entry to the in-memory buffer (non-blocking)."""
        
        try:
            row = (
                api_key_id,
                api_key_hash,
                model,
                endpoint,
                method,
                json.dumps(request_headers) if request_headers else None,
                json.dumps(request_body) if request_body else None,
                json.dumps(response_headers) if response_headers else None,
                json.dumps(response_body) if response_body else None,
                status_code,
                processing_time_ms,
                request_size,
                response_size,
                server_name,
                server_url,
                error_message,
                user_agent,
                ip_address,
            )
            
            with self._buffer_lock:
                self._buffer.append(row)
                buf_len = len(self._buffer)
            
            # If the buffer is large, wake flush early (the loop will pick it up)
            if buf_len >= FLUSH_THRESHOLD:
                self._flush_buffer()
                
        except Exception as e:
            logger.error(f"Failed to buffer query log: {e}")
    
    def _get_write_conn(self) -> sqlite3.Connection:
        """Get or create the persistent write connection."""
        if self._conn is None:
            self._conn = sqlite3.connect(self.current_db_path, timeout=30)
            self._conn.execute('PRAGMA journal_mode=WAL')
            self._conn.execute('PRAGMA synchronous=NORMAL')
        return self._conn
    
    def _flush_buffer(self):
        """Drain the buffer into SQLite in a single transaction."""
        # Swap out the buffer contents under lock
        with self._buffer_lock:
            if not self._buffer:
                return
            batch = list(self._buffer)
            self._buffer.clear()
        
        try:
            conn = self._get_write_conn()
            conn.executemany('''
                INSERT INTO full_query_logs (
                    api_key_id, api_key_hash, model_name, endpoint, method,
                    request_headers, request_body, response_headers, response_body,
                    status_code, processing_time_ms, request_size, response_size,
                    server_name, server_url, error_message, user_agent, ip_address
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', batch)
            conn.commit()
        except Exception as e:
            logger.error(f"Failed to flush {len(batch)} log entries to SQLite: {e}")
            # Put rows back so they aren't lost
            with self._buffer_lock:
                self._buffer.extendleft(reversed(batch))
    
    def _flush_loop(self):
        """Background thread that periodically flushes the buffer."""
        while self._running:
            _time.sleep(FLUSH_INTERVAL_SECONDS)
            try:
                self._flush_buffer()
            except Exception as e:
                logger.error(f"Error in flush loop: {e}")
    
    def shutdown(self):
        """Flush remaining buffer and close connections."""
        self._running = False
        self._flush_buffer()
        if self._conn:
            self._conn.close()
            self._conn = None
    
    def get_daily_log_count(self) -> int:
        """Get the number of logs for today"""
        try:
            conn = sqlite3.connect(self.current_db_path)
            cursor = conn.cursor()
            
            today = datetime.now().date()
            cursor.execute('''
                SELECT COUNT(*) FROM full_query_logs 
                WHERE DATE(timestamp) = ?
            ''', (today,))
            
            count = cursor.fetchone()[0]
            conn.close()
            return count
            
        except Exception as e:
            logger.error(f"Failed to get daily log count: {e}")
            return 0
    
    def create_daily_dump(self) -> str:
        """Create a daily dump of the current logs and reset the database"""
        try:
            # Flush any remaining buffered entries first
            self._flush_buffer()
            
            # Close the persistent write connection so the file isn't locked
            if self._conn:
                self._conn.close()
                self._conn = None
            
            today = datetime.now().strftime("%Y-%m-%d")
            dump_filename = f"full_logs_{today}.db"
            dump_path = os.path.join(self.logs_dir, dump_filename)
            
            # Copy current database to daily dump
            shutil.copy2(self.current_db_path, dump_path)
            
            # Compress the dump
            compressed_path = f"{dump_path}.gz"
            with open(dump_path, 'rb') as f_in:
                with gzip.open(compressed_path, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
            
            # Remove uncompressed dump
            os.remove(dump_path)
            
            # Get log count before reset
            log_count = self.get_daily_log_count()
            
            # Reset current database — VACUUM reclaims space unlike DELETE
            conn = sqlite3.connect(self.current_db_path)
            conn.execute('DELETE FROM full_query_logs')
            conn.execute('VACUUM')
            conn.commit()
            conn.close()
            
            logger.info(f"Created daily dump: {compressed_path} with {log_count} logs")
            return compressed_path
            
        except Exception as e:
            logger.error(f"Failed to create daily dump: {e}")
            raise
    
    def get_log_stats(self) -> Dict[str, Any]:
        """Get statistics about the current logs"""
        try:
            conn = sqlite3.connect(self.current_db_path)
            cursor = conn.cursor()
            
            # Total logs
            cursor.execute('SELECT COUNT(*) FROM full_query_logs')
            total_logs = cursor.fetchone()[0]
            
            # Logs today
            today = datetime.now().date()
            cursor.execute('''
                SELECT COUNT(*) FROM full_query_logs 
                WHERE DATE(timestamp) = ?
            ''', (today,))
            today_logs = cursor.fetchone()[0]
            
            # Model distribution
            cursor.execute('''
                SELECT model_name, COUNT(*) as count 
                FROM full_query_logs 
                GROUP BY model_name 
                ORDER BY count DESC 
                LIMIT 10
            ''')
            model_stats = dict(cursor.fetchall())
            
            # Status code distribution
            cursor.execute('''
                SELECT status_code, COUNT(*) as count 
                FROM full_query_logs 
                WHERE status_code IS NOT NULL
                GROUP BY status_code 
                ORDER BY count DESC
            ''')
            status_stats = dict(cursor.fetchall())
            
            # Average response time
            cursor.execute('''
                SELECT AVG(processing_time_ms) 
                FROM full_query_logs 
                WHERE processing_time_ms IS NOT NULL
            ''')
            avg_response_time = cursor.fetchone()[0]
            
            conn.close()
            
            return {
                'total_logs': total_logs,
                'today_logs': today_logs,
                'model_stats': model_stats,
                'status_stats': status_stats,
                'avg_response_time_ms': round(avg_response_time, 2) if avg_response_time else 0,
                'current_db_path': self.current_db_path
            }
            
        except Exception as e:
            logger.error(f"Failed to get log stats: {e}")
            return {}
    
    def cleanup_old_dumps(self, days_to_keep: int = 30):
        """Clean up old daily dumps"""
        try:
            cutoff_date = datetime.now() - timedelta(days=days_to_keep)
            
            for filename in os.listdir(self.logs_dir):
                if filename.startswith("full_logs_") and filename.endswith(".gz"):
                    # Extract date from filename
                    date_str = filename.replace("full_logs_", "").replace(".gz", "")
                    try:
                        file_date = datetime.strptime(date_str, "%Y-%m-%d")
                        if file_date < cutoff_date:
                            file_path = os.path.join(self.logs_dir, filename)
                            os.remove(file_path)
                            logger.info(f"Removed old dump: {filename}")
                    except ValueError:
                        # Skip files that don't match the expected format
                        continue
                        
        except Exception as e:
            logger.error(f"Failed to cleanup old dumps: {e}")
    
    def list_dumps(self) -> list:
        """List all available daily dumps"""
        dumps = []
        try:
            for filename in os.listdir(self.logs_dir):
                if filename.startswith("full_logs_") and filename.endswith(".gz"):
                    file_path = os.path.join(self.logs_dir, filename)
                    stat = os.stat(file_path)
                    
                    # Extract date from filename
                    date_str = filename.replace("full_logs_", "").replace(".gz", "")
                    try:
                        date = datetime.strptime(date_str, "%Y-%m-%d")
                        dumps.append({
                            'filename': filename,
                            'date': date.strftime("%Y-%m-%d"),
                            'size_bytes': stat.st_size,
                            'size_mb': round(stat.st_size / (1024 * 1024), 2),
                            'path': file_path
                        })
                    except ValueError:
                        continue
            
            # Sort by date (newest first)
            dumps.sort(key=lambda x: x['date'], reverse=True)
            
        except Exception as e:
            logger.error(f"Failed to list dumps: {e}")
        
        return dumps
