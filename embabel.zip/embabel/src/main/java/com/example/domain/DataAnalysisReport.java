package com.example.domain;

import java.util.List;

/**
 * Final report combining data summary and visualization suggestions
 */
public class DataAnalysisReport {
    private DataSummary summary;
    private List<VisualizationSuggestion> visualizationSuggestions;

    public DataAnalysisReport() {}

    public DataSummary getSummary() {
        return summary;
    }

    public void setSummary(DataSummary summary) {
        this.summary = summary;
    }

    public List<VisualizationSuggestion> getVisualizationSuggestions() {
        return visualizationSuggestions;
    }

    public void setVisualizationSuggestions(List<VisualizationSuggestion> visualizationSuggestions) {
        this.visualizationSuggestions = visualizationSuggestions;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== DATA ANALYSIS REPORT ===\n\n");
        sb.append("SUMMARY:\n");
        sb.append("Overview: ").append(summary.getOverview()).append("\n");
        sb.append("Data Quality: ").append(summary.getDataQuality()).append("\n");
        sb.append("\nKey Insights:\n");
        for (String insight : summary.getKeyInsights()) {
            sb.append("  - ").append(insight).append("\n");
        }
        sb.append("\nTrends:\n");
        for (String trend : summary.getTrends()) {
            sb.append("  - ").append(trend).append("\n");
        }
        if (!summary.getAnomalies().isEmpty()) {
            sb.append("\nAnomalies:\n");
            for (String anomaly : summary.getAnomalies()) {
                sb.append("  - ").append(anomaly).append("\n");
            }
        }
        sb.append("\n=== VISUALIZATION SUGGESTIONS ===\n");
        for (VisualizationSuggestion viz : visualizationSuggestions) {
            sb.append("\n").append(viz.getChartType().toUpperCase()).append(" CHART\n");
            sb.append("  Description: ").append(viz.getDescription()).append("\n");
            sb.append("  X-Axis: ").append(viz.getXAxis()).append("\n");
            sb.append("  Y-Axis: ").append(viz.getYAxis()).append("\n");
            sb.append("  Complexity: ").append(viz.getComplexity()).append("\n");
            sb.append("  Rationale: ").append(viz.getRationale()).append("\n");
        }
        return sb.toString();
    }
}
