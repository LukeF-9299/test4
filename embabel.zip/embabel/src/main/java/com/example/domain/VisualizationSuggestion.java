package com.example.domain;

/**
 * Represents a suggestion for visualizing the data
 */
public class VisualizationSuggestion {
    private String chartType; // "bar", "line", "pie", "scatter", "heatmap", etc.
    private String description;
    private String xAxis;
    private String yAxis;
    private String rationale;
    private String complexity; // "simple", "moderate", "complex"

    public VisualizationSuggestion() {}

    public VisualizationSuggestion(String chartType, String description, String xAxis, String yAxis, String rationale, String complexity) {
        this.chartType = chartType;
        this.description = description;
        this.xAxis = xAxis;
        this.yAxis = yAxis;
        this.rationale = rationale;
        this.complexity = complexity;
    }

    public String getChartType() {
        return chartType;
    }

    public void setChartType(String chartType) {
        this.chartType = chartType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getXAxis() {
        return xAxis;
    }

    public void setXAxis(String xAxis) {
        this.xAxis = xAxis;
    }

    public String getYAxis() {
        return yAxis;
    }

    public void setYAxis(String yAxis) {
        this.yAxis = yAxis;
    }

    public String getRationale() {
        return rationale;
    }

    public void setRationale(String rationale) {
        this.rationale = rationale;
    }

    public String getComplexity() {
        return complexity;
    }

    public void setComplexity(String complexity) {
        this.complexity = complexity;
    }

    @Override
    public String toString() {
        return "VisualizationSuggestion{" +
                "chartType='" + chartType + '\'' +
                ", description='" + description + '\'' +
                ", xAxis='" + xAxis + '\'' +
                ", yAxis='" + yAxis + '\'' +
                ", complexity='" + complexity + '\'' +
                '}';
    }
}
