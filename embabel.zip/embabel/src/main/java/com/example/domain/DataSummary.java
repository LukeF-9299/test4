package com.example.domain;

import java.util.List;

/**
 * Represents a summary of the data with key insights
 */
public class DataSummary {
    private String overview;
    private List<String> keyInsights;
    private List<String> trends;
    private List<String> anomalies;
    private String dataQuality;

    public DataSummary() {}

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public List<String> getKeyInsights() {
        return keyInsights;
    }

    public void setKeyInsights(List<String> keyInsights) {
        this.keyInsights = keyInsights;
    }

    public List<String> getTrends() {
        return trends;
    }

    public void setTrends(List<String> trends) {
        this.trends = trends;
    }

    public List<String> getAnomalies() {
        return anomalies;
    }

    public void setAnomalies(List<String> anomalies) {
        this.anomalies = anomalies;
    }

    public String getDataQuality() {
        return dataQuality;
    }

    public void setDataQuality(String dataQuality) {
        this.dataQuality = dataQuality;
    }

    @Override
    public String toString() {
        return "DataSummary{" +
                "overview='" + overview + '\'' +
                ", keyInsights=" + (keyInsights != null ? keyInsights.size() : 0) +
                ", trends=" + (trends != null ? trends.size() : 0) +
                ", anomalies=" + (anomalies != null ? anomalies.size() : 0) +
                ", dataQuality='" + dataQuality + '\'' +
                '}';
    }
}
