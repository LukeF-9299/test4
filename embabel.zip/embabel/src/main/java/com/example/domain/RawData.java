package com.example.domain;

/**
 * Represents raw data input that can be in various formats (JSON, CSV, etc.)
 */
public class RawData {
    private String content;
    private String format; // "json", "csv", "text", etc.
    private String description;

    public RawData() {}

    public RawData(String content, String format, String description) {
        this.content = content;
        this.format = format;
        this.description = description;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "RawData{format='" + format + "', description='" + description + "', content length=" + (content != null ? content.length() : 0) + "}";
    }
}
