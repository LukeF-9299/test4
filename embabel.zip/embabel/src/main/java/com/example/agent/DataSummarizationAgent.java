package com.example.agent;

import com.embabel.agent.annotation.Action;
import com.embabel.agent.annotation.Agent;
import com.embabel.agent.annotation.AchievesGoal;
import com.embabel.agent.api.OperationContext;
import com.example.domain.DataSummary;
import com.example.domain.RawData;
import com.example.domain.VisualizationSuggestion;

import java.util.List;

/**
 * Agent that summarizes raw data and suggests visualizations.
 * Demonstrates domain objects, structured parsing, and multiple LLM configurations.
 */
@Agent(description = "Agent that summarizes raw data and suggests visualizations")
public class DataSummarizationAgent {

    /**
     * Parses raw data into a structured RawData object.
     * Uses a low-temperature LLM for precise parsing.
     */
    @Action
    public RawData parseData(String userInput, OperationContext context) {
        String prompt = """
            You are a data parser. Analyze the following data and extract its structure.
            
            Input data:
            %s
            
            Return a JSON object with:
            - content: the original data content
            - format: the data format (json, csv, text, etc.)
            - description: a brief description of what the data represents
            """.formatted(userInput);

        return context.ai()
                .withLlmByRole("parser")
                .createObject(prompt, RawData.class);
    }

    /**
     * Summarizes the parsed data to extract key insights.
     * Uses a medium-temperature LLM for balanced analysis.
     */
    @Action
    public DataSummary summarizeData(RawData rawData, OperationContext context) {
        String prompt = """
            You are a data analyst. Analyze the following data and provide a comprehensive summary.
            
            Data format: %s
            Data description: %s
            Data content:
            %s
            
            Provide:
            - overview: a high-level summary of the data
            - keyInsights: 3-5 key insights from the data
            - trends: any trends or patterns you observe
            - anomalies: any unusual or unexpected data points
            - dataQuality: assessment of data quality (excellent, good, fair, poor)
            """.formatted(
                rawData.getFormat(),
                rawData.getDescription(),
                rawData.getContent()
        );

        return context.ai()
                .withLlmByRole("analyst")
                .createObject(prompt, DataSummary.class);
    }

    /**
     * Suggests appropriate visualizations for the data.
     * Uses a creative LLM for visualization recommendations.
     */
    @Action
    public List<VisualizationSuggestion> suggestVisualizations(DataSummary summary, RawData rawData, OperationContext context) {
        String prompt = """
            You are a data visualization expert. Based on the following data summary, suggest 3-5 appropriate visualizations.
            
            Data Summary:
            - Overview: %s
            - Key Insights: %s
            - Trends: %s
            - Data Format: %s
            
            For each visualization suggestion, provide:
            - chartType: type of chart (bar, line, pie, scatter, heatmap, etc.)
            - description: what this visualization would show
            - xAxis: what would be on the x-axis
            - yAxis: what would be on the y-axis
            - rationale: why this visualization is appropriate
            - complexity: simple, moderate, or complex
            
            Focus on visualizations that would best communicate the insights from this data.
            """.formatted(
                summary.getOverview(),
                String.join(", ", summary.getKeyInsights()),
                String.join(", ", summary.getTrends()),
                rawData.getFormat()
        );

        return context.ai()
                .withLlmByRole("visualizer")
                .createObject(prompt, 
                    context.ai().getTypeFactory().parameterizedType(List.class, VisualizationSuggestion.class));
    }

    /**
     * Final action that combines the summary and visualization suggestions.
     * This is marked as achieving the goal.
     */
    @AchievesGoal(description = "Generate final report with summary and visualization suggestions")
    @Action
    public DataAnalysisReport generateFinalReport(
            DataSummary summary,
            List<VisualizationSuggestion> visualizations,
            OperationContext context) {
        
        DataAnalysisReport report = new DataAnalysisReport();
        report.setSummary(summary);
        report.setVisualizationSuggestions(visualizations);
        
        return report;
    }
}
