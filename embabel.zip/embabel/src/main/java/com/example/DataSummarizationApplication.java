package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main Spring Boot application for the Data Summarization Agent
 */
@SpringBootApplication
public class DataSummarizationApplication {

    public static void main(String[] args) {
        SpringApplication.run(DataSummarizationApplication.class, args);
    }
}
