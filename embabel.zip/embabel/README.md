# Data Summarization Agent

An Embabel-based agent that summarizes raw data (JSON, CSV, text) and suggests appropriate visualizations. This project demonstrates key Embabel concepts including domain objects, multiple LLM configurations, and structured output.

## Features

- **Data Parsing**: Intelligently parses raw data in various formats (JSON, CSV, text)
- **Automated Summarization**: Extracts key insights, trends, and anomalies from data
- **Visualization Suggestions**: Recommends appropriate chart types based on data characteristics
- **Multiple LLM Configurations**: Uses different LLM settings for different tasks (parsing, analysis, visualization)

## Requirements

- Java 17 or higher
- Maven 3.6+
- Local LLM server (e.g., Ollama, vLLM, LM Studio) with OpenAI-compatible API
  - URL of the local LLM endpoint
  - Model name
  - API key (if required)

## Setup

1. **Configure your local LLM environment variables**:
   ```bash
   export LOCAL_LLM_URL="http://localhost:11434/v1"  # Your local LLM endpoint
   export LOCAL_LLM_MODEL="llama3"                  # Your model name
   export LOCAL_LLM_API_KEY="dummy-key"             # API key (use "dummy-key" if not required)
   ```

   **Common Local LLM Endpoints:**
   - Ollama: `http://localhost:11434/v1`
   - vLLM: `http://localhost:8000/v1`
   - LM Studio: `http://localhost:1234/v1`

2. **Build the project**:
   ```bash
   mvn clean install
   ```

3. **Run the application**:
   ```bash
   mvn spring-boot:run
   ```

## Usage

The agent can be invoked programmatically or through Spring Shell. Here's how to use it:

### Example 1: CSV Sales Data

```java
String csvData = """
    product,month,sales,revenue
    Widget A,January,150,4500
    Widget A,February,180,5400
    Widget B,January,120,3600
    Widget B,February,140,4200
    """;

// Invoke the agent with the data
DataAnalysisReport report = agentPlatform.execute(
    DataSummarizationAgent.class, 
    csvData
);

System.out.println(report);
```

### Example 2: JSON User Data

```java
String jsonData = """
    [
      {"name": "Alice", "age": 28, "department": "Engineering", "salary": 85000},
      {"name": "Bob", "age": 35, "department": "Marketing", "salary": 72000},
      {"name": "Charlie", "age": 42, "department": "Engineering", "salary": 95000}
    ]
    """;

DataAnalysisReport report = agentPlatform.execute(
    DataSummarizationAgent.class, 
    jsonData
);
```

### Example 3: Text Data

```java
String textData = """
    Q1 2024 Financial Results:
    - Revenue: $2.5M (up 15% from Q4 2023)
    - Expenses: $1.8M (down 5% from Q4 2023)
    - Net Profit: $700K
    - Customer acquisition cost: $250
    - Customer lifetime value: $2,500
    """;

DataAnalysisReport report = agentPlatform.execute(
    DataSummarizationAgent.class, 
    textData
);
```

## Project Structure

```
src/main/java/com/example/
├── DataSummarizationApplication.java    # Main Spring Boot application
├── agent/
│   └── DataSummarizationAgent.java      # The Embabel agent with actions
└── domain/
    ├── RawData.java                      # Input data representation
    ├── DataSummary.java                 # Summary with insights
    ├── VisualizationSuggestion.java     # Chart recommendations
    └── DataAnalysisReport.java          # Final combined report
```

## Embabel Concepts Demonstrated

### 1. Domain Objects
Strongly-typed objects that structure the interaction between actions:
- `RawData`: Represents the input data
- `DataSummary`: Contains insights, trends, and anomalies
- `VisualizationSuggestion`: Chart recommendations
- `DataAnalysisReport`: Final combined output

### 2. Multiple LLM Configurations
Different LLM settings for different tasks:
- **Parser** (temperature: 0.1): Precise data parsing
- **Analyst** (temperature: 0.5): Balanced data analysis
- **Visualizer** (temperature: 0.8): Creative visualization suggestions

### 3. Actions and Goals
- `@Action`: Methods that represent steps the agent can take
- `@AchievesGoal`: Marks the final action that completes the agent's work

### 4. Structured Output
Uses LLMs to generate strongly-typed objects directly, avoiding magic maps.

## Configuration

LLM configurations are in `src/main/resources/application.yml` and use environment variables for flexibility:

```yaml
spring:
  ai:
    openai:
      api-key: ${LOCAL_LLM_API_KEY:dummy-key}
      base-url: ${LOCAL_LLM_URL:http://localhost:11434/v1}
      chat:
        options:
          model: ${LOCAL_LLM_MODEL:llama3}

embabel:
  llm:
    default:
      provider: openai
      model: ${LOCAL_LLM_MODEL:llama3}
      temperature: 0.7
    parser:
      provider: openai
      model: ${LOCAL_LLM_MODEL:llama3}
      temperature: 0.1
    analyst:
      provider: openai
      model: ${LOCAL_LLM_MODEL:llama3}
      temperature: 0.5
    visualizer:
      provider: openai
      model: ${LOCAL_LLM_MODEL:llama3}
      temperature: 0.8
```

The configuration uses OpenAI-compatible API format, which works with most local LLM servers (Ollama, vLLM, LM Studio, etc.). Set the environment variables before running the application to customize your local LLM endpoint and model.

## Customization

You can extend this agent by:
- Adding new actions for additional analysis types
- Creating new domain objects for different data structures
- Configuring additional LLM providers
- Adding tool integrations (e.g., database connectors, file readers)

## Resources

- [Embabel Documentation](https://docs.embabel.com/embabel-agent/guide/0.1.3/)
- [Embabel GitHub](https://github.com/embabel/embabel-agent)
- [Embabel Examples](https://github.com/embabel/embabel-agent-examples)
