"""Workspace sandbox: confine all filesystem access to a single root folder."""

from __future__ import annotations

from pathlib import Path


class SandboxError(Exception):
    """Raised when a path would escape the workspace root."""


class Sandbox:
    def __init__(self, root: str | Path):
        self.root = Path(root).expanduser().resolve()
        if not self.root.exists():
            self.root.mkdir(parents=True, exist_ok=True)
        if not self.root.is_dir():
            raise SandboxError(f"Workspace root is not a directory: {self.root}")

    def resolve(self, relative_path: str | Path) -> Path:
        """Resolve a workspace-relative path, rejecting any escape attempt."""
        p = Path(relative_path)
        if p.is_absolute():
            raise SandboxError(f"Absolute paths are not allowed: {relative_path}")
        candidate = (self.root / p).resolve()
        if candidate != self.root and self.root not in candidate.parents:
            raise SandboxError(f"Path escapes the workspace: {relative_path}")
        return candidate

    def relpath(self, path: str | Path) -> str:
        return str(Path(path).resolve().relative_to(self.root))
