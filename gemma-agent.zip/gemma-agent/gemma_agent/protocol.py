"""Prompt-based tool-call protocol: render instructions and parse model actions."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field

FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL)

PROTOCOL_INSTRUCTIONS = """
RESPONSE FORMAT (strict):
On every turn reply with a SINGLE fenced json block containing exactly one object:

```json
{"thought": "<one short sentence of reasoning>", "action": "<action_name>", "args": {<arguments>}}
```

Rules:
- Output nothing outside the json block.
- Use exactly one action per turn and one of the action names listed above.
- When the task is complete, use the "final" action with your summary in "answer".
"""


@dataclass
class Action:
    action: str
    args: dict = field(default_factory=dict)
    thought: str = ""


class ProtocolError(Exception):
    pass


def render_tools_doc(tools: dict, extra_specs: list[tuple] | None = None) -> str:
    """Build the protocol + action catalogue section of a system prompt.

    extra_specs entries are (name, description, args_doc, required).
    """
    specs: list[tuple] = [
        (t.name, t.description, t.args_doc, t.required) for t in tools.values()
    ]
    if extra_specs:
        specs.extend(extra_specs)
    specs.append((
        "final",
        "Finish and return your result to whoever called you.",
        {"answer": "Your final answer or summary of what you did."},
        ["answer"],
    ))

    lines = ["AVAILABLE ACTIONS:"]
    for name, desc, args_doc, required in specs:
        lines.append(f"\n- {name}: {desc}")
        for arg, adesc in (args_doc or {}).items():
            tag = "required" if arg in (required or []) else "optional"
            lines.append(f"    - {arg} ({tag}): {adesc}")
    lines.append(PROTOCOL_INSTRUCTIONS)
    return "\n".join(lines)


def _try_load(text: str) -> dict | None:
    try:
        obj = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return None
    return obj if isinstance(obj, dict) else None


def _extract_braces(text: str) -> str | None:
    """Return the first balanced {...} substring, if any."""
    start = text.find("{")
    if start == -1:
        return None
    depth = 0
    in_str = False
    escape = False
    for i in range(start, len(text)):
        ch = text[i]
        if in_str:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return text[start:i + 1]
    return None


def _validate(obj: dict) -> Action:
    action = obj.get("action")
    if not isinstance(action, str) or not action:
        raise ProtocolError("Missing or invalid 'action' field.")
    args = obj.get("args", {})
    if not isinstance(args, dict):
        raise ProtocolError("'args' must be an object.")
    thought = obj.get("thought", "")
    return Action(action=action, args=args, thought=str(thought))


def parse_action(text: str) -> Action:
    """Extract one Action from raw model output, trying several strategies."""
    for block in reversed(FENCE_RE.findall(text)):
        obj = _try_load(block.strip()) or _try_load(_extract_braces(block) or "")
        if obj is not None:
            return _validate(obj)

    obj = _try_load(text.strip())
    if obj is not None:
        return _validate(obj)

    extracted = _extract_braces(text)
    if extracted:
        obj = _try_load(extracted)
        if obj is not None:
            return _validate(obj)

    raise ProtocolError("No valid JSON action found in the model output.")
