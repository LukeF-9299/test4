"""Sandboxed multi-agent coding assistant for a local Gemma OpenAI-compatible endpoint."""

__version__ = "0.1.0"
