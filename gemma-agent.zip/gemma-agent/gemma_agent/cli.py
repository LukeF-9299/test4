"""Command-line entrypoint for the Gemma agent."""

from __future__ import annotations

import argparse
import sys

from .agents.orchestrator import Orchestrator
from .config import load_config
from .llm import LLM
from .sandbox import Sandbox
from .tools import build_tools
from .ui import ConsoleUI


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Sandboxed multi-agent coding assistant for a local Gemma endpoint.",
    )
    parser.add_argument("--workspace", "-w", required=True,
                        help="Folder the agents may operate in (created if missing).")
    parser.add_argument("--config", "-c", default="config.yaml",
                        help="Path to the YAML config file (default: config.yaml).")
    parser.add_argument("--quiet", action="store_true",
                        help="Suppress the step-by-step trace.")
    parser.add_argument("task", nargs="*",
                        help="The task to perform. If omitted, starts interactive mode.")
    args = parser.parse_args(argv)

    config = load_config(args.config)
    sandbox = Sandbox(args.workspace)
    llm = LLM(config.llm)
    tools = build_tools(sandbox, config)
    ui = None if args.quiet else ConsoleUI()

    def run_task(task: str) -> None:
        result = Orchestrator(llm, tools, config, ui).run(task)
        print("\n=== RESULT ===\n" + result)

    if args.task:
        run_task(" ".join(args.task))
        return 0

    print(f"Gemma agent ready. Workspace: {sandbox.root}")
    print("Type a task, or 'exit' to quit.")
    while True:
        try:
            task = input("\n> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if task.lower() in ("exit", "quit"):
            break
        if task:
            run_task(task)
    return 0


if __name__ == "__main__":
    sys.exit(main())
