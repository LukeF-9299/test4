"""Configuration loading with ${ENV_VAR} interpolation."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

_ENV_PATTERN = re.compile(r"\$\{([^}]+)\}")


def _expand(value: Any) -> Any:
    """Recursively expand ${ENV_VAR} references in strings."""
    if isinstance(value, str):
        return _ENV_PATTERN.sub(lambda m: os.environ.get(m.group(1), ""), value)
    if isinstance(value, dict):
        return {k: _expand(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_expand(v) for v in value]
    return value


@dataclass
class LLMConfig:
    base_url: str = "http://localhost:8000/v1"
    model: str = "google/gemma-2-9b-it"
    api_key: str = "EMPTY"
    headers: dict = field(default_factory=dict)
    temperature: float = 0.2
    max_tokens: int = 2048
    request_timeout: float = 120.0


@dataclass
class Limits:
    max_steps: int = 25
    run_python_timeout: int = 60
    max_output_chars: int = 8000


@dataclass
class Config:
    llm: LLMConfig
    limits: Limits


def load_config(path: str | Path) -> Config:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    raw = _expand(raw)

    llm_raw = raw.get("llm", {}) or {}
    # Drop empty header values so we don't send blank headers.
    headers = {k: v for k, v in (llm_raw.get("headers") or {}).items() if v}
    llm_raw["headers"] = headers

    llm = LLMConfig(**{k: v for k, v in llm_raw.items() if k in LLMConfig.__dataclass_fields__})
    limits_raw = raw.get("limits", {}) or {}
    limits = Limits(**{k: v for k, v in limits_raw.items() if k in Limits.__dataclass_fields__})
    return Config(llm=llm, limits=limits)
