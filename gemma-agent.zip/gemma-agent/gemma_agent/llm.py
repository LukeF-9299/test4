"""Thin OpenAI-compatible client wrapper with Gemma-friendly message handling."""

from __future__ import annotations

from typing import Any

from openai import OpenAI

from .config import LLMConfig


def prepare_for_gemma(messages: list[dict]) -> list[dict]:
    """Adapt standard chat messages to Gemma's constraints.

    Gemma's chat template:
      * has no `system` role  -> fold system content into the first user turn
      * requires strictly alternating user/assistant turns -> merge consecutive
        same-role messages and ensure the conversation starts with `user`.
    """
    system_text = "\n\n".join(
        m["content"] for m in messages
        if m.get("role") == "system" and m.get("content")
    ).strip()

    convo = [
        {"role": m["role"], "content": m.get("content", "")}
        for m in messages
        if m.get("role") in ("user", "assistant")
    ]

    if not convo:
        convo = [{"role": "user", "content": ""}]

    if system_text:
        for m in convo:
            if m["role"] == "user":
                m["content"] = f"{system_text}\n\n{m['content']}".strip()
                break
        else:
            convo.insert(0, {"role": "user", "content": system_text})

    merged: list[dict] = []
    for m in convo:
        if merged and merged[-1]["role"] == m["role"]:
            merged[-1]["content"] = f"{merged[-1]['content']}\n\n{m['content']}".strip()
        else:
            merged.append(dict(m))

    if merged[0]["role"] != "user":
        merged.insert(0, {"role": "user", "content": "(begin)"})

    return merged


class LLM:
    def __init__(self, cfg: LLMConfig):
        self.cfg = cfg
        self.client = OpenAI(
            base_url=cfg.base_url,
            api_key=cfg.api_key or "EMPTY",
            default_headers=cfg.headers or None,
            timeout=cfg.request_timeout,
        )

    def chat(self, messages: list[dict], **overrides: Any) -> str:
        prepared = prepare_for_gemma(messages)
        resp = self.client.chat.completions.create(
            model=overrides.get("model", self.cfg.model),
            messages=prepared,
            temperature=overrides.get("temperature", self.cfg.temperature),
            max_tokens=overrides.get("max_tokens", self.cfg.max_tokens),
        )
        return resp.choices[0].message.content or ""
