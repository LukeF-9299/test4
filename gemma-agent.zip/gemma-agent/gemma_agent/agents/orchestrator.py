from __future__ import annotations

from ..protocol import Action
from .base import BaseAgent
from .coder import CoderAgent
from .reviewer import ReviewerAgent
from .tester import TesterAgent


class Orchestrator(BaseAgent):
    role = "orchestrator"
    prompt_file = "orchestrator.txt"
    tool_names = ["read_file", "list_dir", "search"]

    def __init__(self, llm, tools, config, ui=None):
        super().__init__(llm, tools, config, ui)
        self.subagent_classes = {
            "coder": CoderAgent,
            "tester": TesterAgent,
            "reviewer": ReviewerAgent,
        }

    def extra_action_specs(self) -> list[tuple]:
        names = ", ".join(self.subagent_classes)
        return [(
            "delegate",
            f"Assign a self-contained subtask to a specialist sub-agent ({names}). "
            "Returns that sub-agent's final result.",
            {
                "agent": f"One of: {names}.",
                "task": "A clear, self-contained instruction for the sub-agent.",
                "context": "Optional extra context (files, prior results).",
            },
            ["agent", "task"],
        )]

    def dispatch(self, action: Action) -> str:
        if action.action == "delegate":
            return self._delegate(action.args or {})
        return super().dispatch(action)

    def _delegate(self, args: dict) -> str:
        name = args.get("agent")
        task = args.get("task")
        context = args.get("context", "")
        cls = self.subagent_classes.get(name)
        if cls is None:
            return f"ERROR: unknown agent '{name}'. Options: {', '.join(self.subagent_classes)}."
        if not task:
            return "ERROR: 'task' is required for delegate."
        agent = cls(self.llm, self._all_tools, self.config, self.ui)
        result = agent.run(str(task), str(context))
        return f"[{name} result]\n{result}"
