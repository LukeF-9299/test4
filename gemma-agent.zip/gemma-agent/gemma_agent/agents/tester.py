from __future__ import annotations

from .base import BaseAgent


class TesterAgent(BaseAgent):
    role = "tester"
    prompt_file = "tester.txt"
    tool_names = ["read_file", "list_dir", "search", "run_python"]
