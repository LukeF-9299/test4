from __future__ import annotations

from .base import BaseAgent


class CoderAgent(BaseAgent):
    role = "coder"
    prompt_file = "coder.txt"
    tool_names = ["read_file", "list_dir", "search", "write_file", "edit_file"]
