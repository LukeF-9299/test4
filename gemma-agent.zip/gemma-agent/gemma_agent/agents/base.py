"""BaseAgent: a ReAct-style loop driven by the JSON tool protocol."""

from __future__ import annotations

from pathlib import Path

from ..config import Config
from ..llm import LLM
from ..protocol import Action, ProtocolError, parse_action, render_tools_doc

_PROMPT_DIR = Path(__file__).resolve().parent.parent / "prompts"


class BaseAgent:
    role: str = "agent"
    prompt_file: str = ""
    tool_names: list[str] = []

    def __init__(self, llm: LLM, tools: dict, config: Config, ui=None):
        self.llm = llm
        self.config = config
        self.ui = ui
        self._all_tools = tools
        self.tools = {n: tools[n] for n in self.tool_names if n in tools}

    # --- prompt construction -------------------------------------------------
    def persona(self) -> str:
        return (_PROMPT_DIR / self.prompt_file).read_text(encoding="utf-8").strip()

    def extra_action_specs(self) -> list[tuple]:
        return []

    def system_prompt(self) -> str:
        return self.persona() + "\n\n" + render_tools_doc(self.tools, self.extra_action_specs())

    def initial_message(self, task: str, context: str) -> str:
        msg = f"TASK:\n{task}"
        if context:
            msg += f"\n\nCONTEXT:\n{context}"
        return msg

    # --- loop ----------------------------------------------------------------
    def run(self, task: str, context: str = "") -> str:
        messages = [
            {"role": "system", "content": self.system_prompt()},
            {"role": "user", "content": self.initial_message(task, context)},
        ]
        if self.ui:
            self.ui.agent_start(self.role, task)

        for _ in range(self.config.limits.max_steps):
            text = self.llm.chat(messages)
            messages.append({"role": "assistant", "content": text})

            try:
                action = parse_action(text)
            except ProtocolError as e:
                messages.append({
                    "role": "user",
                    "content": f"FORMAT ERROR: {e} Reply with exactly one ```json action block.",
                })
                continue

            if self.ui:
                self.ui.agent_step(self.role, action)

            if action.action == "final":
                answer = str(action.args.get("answer", "")).strip()
                if self.ui:
                    self.ui.agent_finish(self.role, answer)
                return answer

            obs = self.dispatch(action)
            if self.ui:
                self.ui.observation(self.role, action.action, obs)
            messages.append({
                "role": "user",
                "content": f"OBSERVATION ({action.action}):\n{obs}",
            })

        return f"ERROR: {self.role} reached the max step limit without finishing."

    # --- dispatch ------------------------------------------------------------
    def dispatch(self, action: Action) -> str:
        tool = self.tools.get(action.action)
        if tool is None:
            available = ", ".join(list(self.tools) + ["final"])
            return f"ERROR: unknown action '{action.action}'. Available: {available}."
        try:
            return tool.run(**(action.args or {}))
        except TypeError as e:
            return f"ERROR: bad arguments for {action.action}: {e}"
        except Exception as e:  # noqa: BLE001 - surface tool errors to the model
            return f"ERROR running {action.action}: {e}"
