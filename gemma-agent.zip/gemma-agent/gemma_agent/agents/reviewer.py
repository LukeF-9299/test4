from __future__ import annotations

from .base import BaseAgent


class ReviewerAgent(BaseAgent):
    role = "reviewer"
    prompt_file = "reviewer.txt"
    tool_names = ["read_file", "list_dir", "search"]
