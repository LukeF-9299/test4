from __future__ import annotations

from .base import Tool


class ReadFileTool(Tool):
    name = "read_file"
    description = "Read a UTF-8 text file inside the workspace. Returns line-numbered content."
    args_doc = {"path": "File path relative to the workspace root."}
    required = ["path"]

    def run(self, path: str = "", **_) -> str:
        if not path:
            return "ERROR: 'path' is required."
        target = self.sandbox.resolve(path)
        if not target.exists():
            return f"ERROR: file not found: {path}"
        if not target.is_file():
            return f"ERROR: not a file: {path}"
        try:
            text = target.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            return f"ERROR: file is not valid UTF-8 text: {path}"
        if not text:
            return "(empty file)"
        numbered = "\n".join(
            f"{i:>5}  {line}" for i, line in enumerate(text.splitlines(), 1)
        )
        return self._truncate(numbered)
