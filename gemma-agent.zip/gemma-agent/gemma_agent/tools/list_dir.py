from __future__ import annotations

from .base import Tool, _as_bool


class ListDirTool(Tool):
    name = "list_dir"
    description = "List files and folders in the workspace."
    args_doc = {
        "path": "Directory relative to root (default '.').",
        "recursive": "true/false; walk subfolders (default false).",
    }
    required = []

    def run(self, path: str = ".", recursive=False, **_) -> str:
        target = self.sandbox.resolve(path)
        if not target.exists():
            return f"ERROR: directory not found: {path}"
        if not target.is_dir():
            return f"ERROR: not a directory: {path}"

        lines: list[str] = []
        if _as_bool(recursive):
            for p in sorted(target.rglob("*")):
                suffix = "/" if p.is_dir() else ""
                lines.append(self.sandbox.relpath(p) + suffix)
        else:
            for p in sorted(target.iterdir()):
                if p.is_dir():
                    lines.append(p.name + "/")
                else:
                    lines.append(f"{p.name}  ({p.stat().st_size} bytes)")
        return self._truncate("\n".join(lines) if lines else "(empty directory)")
