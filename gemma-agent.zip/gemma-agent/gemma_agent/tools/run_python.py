from __future__ import annotations

import subprocess
import sys

from .base import Tool


class RunPythonTool(Tool):
    name = "run_python"
    description = (
        "Run a Python script (.py) located in the workspace and capture its output. "
        "This is the ONLY way to execute code."
    )
    args_doc = {
        "path": "Path to a .py script relative to root.",
        "args": "Optional list of string command-line arguments.",
    }
    required = ["path"]

    def run(self, path: str = "", args=None, **_) -> str:
        if not path:
            return "ERROR: 'path' is required."
        target = self.sandbox.resolve(path)
        if target.suffix != ".py":
            return "ERROR: only .py scripts may be run."
        if not target.exists() or not target.is_file():
            return f"ERROR: script not found: {path}"

        cmd = [sys.executable, str(target)]
        if args:
            if isinstance(args, str):
                args = [args]
            cmd += [str(a) for a in args]

        try:
            proc = subprocess.run(
                cmd,
                cwd=str(self.sandbox.root),
                capture_output=True,
                text=True,
                timeout=self.config.limits.run_python_timeout,
            )
        except subprocess.TimeoutExpired:
            return f"ERROR: script timed out after {self.config.limits.run_python_timeout}s."

        out = (
            f"exit_code: {proc.returncode}\n"
            f"--- stdout ---\n{proc.stdout}\n"
            f"--- stderr ---\n{proc.stderr}"
        )
        return self._truncate(out)
