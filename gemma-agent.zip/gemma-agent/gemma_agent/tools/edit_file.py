from __future__ import annotations

from .base import Tool


class EditFileTool(Tool):
    name = "edit_file"
    description = (
        "Replace an exact text snippet in an existing file. "
        "old_string must appear exactly once."
    )
    args_doc = {
        "path": "File path relative to root.",
        "old_string": "Exact text to find (must be unique in the file).",
        "new_string": "Replacement text.",
    }
    required = ["path", "old_string", "new_string"]

    def run(self, path: str = "", old_string: str = "", new_string: str = "", **_) -> str:
        if not path:
            return "ERROR: 'path' is required."
        target = self.sandbox.resolve(path)
        if not target.exists() or not target.is_file():
            return f"ERROR: file not found: {path}"
        try:
            text = target.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            return f"ERROR: file is not valid UTF-8 text: {path}"
        count = text.count(old_string)
        if count == 0:
            return "ERROR: old_string not found in file."
        if count > 1:
            return f"ERROR: old_string appears {count} times; add context to make it unique."
        target.write_text(text.replace(old_string, new_string), encoding="utf-8")
        return f"Edited {path}"
