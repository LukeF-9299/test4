from __future__ import annotations

from .base import Tool


class WriteFileTool(Tool):
    name = "write_file"
    description = "Create or overwrite a text file with the given full content."
    args_doc = {
        "path": "File path relative to root (parent folders are created).",
        "content": "Complete file content to write.",
    }
    required = ["path", "content"]

    def run(self, path: str = "", content: str = "", **_) -> str:
        if not path:
            return "ERROR: 'path' is required."
        target = self.sandbox.resolve(path)
        if target.exists() and target.is_dir():
            return f"ERROR: path is a directory: {path}"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return f"Wrote {len(content)} chars to {path}"
