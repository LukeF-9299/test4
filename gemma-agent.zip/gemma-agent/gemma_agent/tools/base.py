"""Tool base class. Tools always return a string observation for the model."""

from __future__ import annotations

from ..config import Config
from ..sandbox import Sandbox


class Tool:
    name: str = ""
    description: str = ""
    args_doc: dict = {}
    required: list = []

    def __init__(self, sandbox: Sandbox, config: Config):
        self.sandbox = sandbox
        self.config = config

    def run(self, **kwargs) -> str:  # pragma: no cover - interface
        raise NotImplementedError

    def _truncate(self, text: str) -> str:
        limit = self.config.limits.max_output_chars
        if len(text) > limit:
            return text[:limit] + f"\n... [truncated {len(text) - limit} chars]"
        return text


def _as_bool(value) -> bool:
    return value in (True, "true", "True", "1", 1)
