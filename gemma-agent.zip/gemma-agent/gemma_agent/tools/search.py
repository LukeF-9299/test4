from __future__ import annotations

import re

from .base import Tool, _as_bool

_MAX_RESULTS = 200


class SearchTool(Tool):
    name = "search"
    description = "Search workspace text files for a substring (or regex). Returns matching lines."
    args_doc = {
        "query": "Text or regex pattern to search for.",
        "path": "Subdirectory to search (default '.').",
        "regex": "true/false; treat query as a regex (default false).",
    }
    required = ["query"]

    def run(self, query: str = "", path: str = ".", regex=False, **_) -> str:
        if not query:
            return "ERROR: 'query' is required."
        base = self.sandbox.resolve(path)
        if not base.exists():
            return f"ERROR: path not found: {path}"

        pattern = None
        if _as_bool(regex):
            try:
                pattern = re.compile(query)
            except re.error as e:
                return f"ERROR: invalid regex: {e}"

        results: list[str] = []
        targets = [base] if base.is_file() else sorted(base.rglob("*"))
        for p in targets:
            if not p.is_file():
                continue
            try:
                text = p.read_text(encoding="utf-8")
            except (UnicodeDecodeError, OSError):
                continue
            for i, line in enumerate(text.splitlines(), 1):
                hit = pattern.search(line) if pattern else (query in line)
                if hit:
                    results.append(f"{self.sandbox.relpath(p)}:{i}: {line.strip()}")
                    if len(results) >= _MAX_RESULTS:
                        results.append("... [result limit reached]")
                        return self._truncate("\n".join(results))
        return self._truncate("\n".join(results) if results else "(no matches)")
