"""Sandboxed tool registry."""

from __future__ import annotations

from ..config import Config
from ..sandbox import Sandbox
from .base import Tool
from .edit_file import EditFileTool
from .list_dir import ListDirTool
from .read_file import ReadFileTool
from .run_python import RunPythonTool
from .search import SearchTool
from .write_file import WriteFileTool

_TOOL_CLASSES = [
    ReadFileTool,
    ListDirTool,
    WriteFileTool,
    EditFileTool,
    RunPythonTool,
    SearchTool,
]


def build_tools(sandbox: Sandbox, config: Config) -> dict[str, Tool]:
    return {cls.name: cls(sandbox, config) for cls in _TOOL_CLASSES}


__all__ = ["build_tools", "Tool"]
