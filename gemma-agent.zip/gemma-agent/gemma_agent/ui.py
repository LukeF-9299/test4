"""Rich console UI for streaming the agents' step-by-step trace."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel

_PREVIEW = 1500


class ConsoleUI:
    def __init__(self):
        self.console = Console()

    def agent_start(self, role: str, task: str) -> None:
        self.console.rule(f"[bold cyan]{role}[/]")
        self.console.print(f"[dim]task:[/] {task}")

    def agent_step(self, role: str, action) -> None:
        if action.thought:
            self.console.print(f"[yellow]{role} · thought:[/] {action.thought}")
        self.console.print(f"[green]{role} · action:[/] {action.action}  [dim]{action.args}[/]")

    def observation(self, role: str, name: str, obs: str) -> None:
        text = obs if len(obs) <= _PREVIEW else obs[:_PREVIEW] + "\n...[truncated]"
        self.console.print(Panel(text, title=f"observation · {name}", border_style="blue"))

    def agent_finish(self, role: str, answer: str) -> None:
        self.console.print(Panel(answer or "(no answer)", title=f"{role} · final", border_style="magenta"))
