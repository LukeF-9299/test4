# Gemma Agent

A sandboxed, multi-agent coding assistant built for a **Gemma** model served on a
local **OpenAI-compatible** endpoint (e.g. vLLM).

## Key properties

- **Sandboxed.** Every action is confined to a single workspace folder. Paths that
  try to escape the folder (`..`, absolute paths, symlink breakout) are rejected.
- **Python-only execution.** The only way to run code is `run_python`, which runs a
  `.py` script *inside* the workspace. There is no general shell tool.
- **Prompt-based tool protocol.** The model emits a single JSON action per turn,
  which is parsed and executed. This avoids relying on a server-side tool parser,
  which is unreliable for Gemma.
- **Gemma-aware.** Gemma's chat template has no `system` role and requires strictly
  alternating `user`/`model` turns. The LLM wrapper folds system prompts into the
  first user turn and merges consecutive same-role turns automatically.
- **Custom headers.** For non-standard OpenAI-compatible gateways, arbitrary headers
  are sent on every request (configured in `config.yaml`).

## Agents

- **Orchestrator** — plans the task and delegates subtasks. Can read/list/search.
- **Coder** — writes and edits Python files.
- **Tester** — runs Python scripts and reports results (cannot edit files).
- **Reviewer** — reads code and returns findings (read-only).

## Setup

```bash
python -m venv .venv
.venv\Scripts\activate        # Windows
pip install -r requirements.txt
```

Edit `config.yaml` with your endpoint, model name, and any custom headers.
Secrets can be referenced via environment variables, e.g.:

```yaml
llm:
  headers:
    Authorization: "Bearer ${GEMMA_TOKEN}"
```

```bash
set GEMMA_TOKEN=...   # Windows (PowerShell: $env:GEMMA_TOKEN="...")
```

## Usage

Run a one-shot task against a workspace folder:

```bash
python run.py --workspace ./my_project "Create a CLI calculator and a test script for it"
```

Interactive mode (omit the task):

```bash
python run.py --workspace ./my_project
```

Options:

- `--workspace, -w` (required) the folder the agent may operate in (created if missing).
- `--config, -c` path to config file (default `config.yaml`).
- `--quiet` suppress the step-by-step trace.

## Extending

Add a new specialist agent by subclassing `BaseAgent` in `gemma_agent/agents/`,
adding a persona file in `gemma_agent/prompts/`, and registering it in
`Orchestrator.subagent_classes`. Add a new tool by subclassing `Tool` in
`gemma_agent/tools/` and adding it to `build_tools`.

## Tests

```bash
pytest
```
