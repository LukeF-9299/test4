"""Entry point: python run.py --workspace ./project "your task"."""

from gemma_agent.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
