import pytest

from gemma_agent.sandbox import Sandbox, SandboxError


def test_resolve_inside_root(tmp_path):
    sb = Sandbox(tmp_path)
    p = sb.resolve("sub/file.py")
    assert str(p).startswith(str(tmp_path))


def test_root_itself_allowed(tmp_path):
    sb = Sandbox(tmp_path)
    assert sb.resolve(".") == sb.root


def test_reject_parent_escape(tmp_path):
    sb = Sandbox(tmp_path)
    with pytest.raises(SandboxError):
        sb.resolve("../outside.txt")


def test_reject_absolute_path(tmp_path):
    sb = Sandbox(tmp_path)
    with pytest.raises(SandboxError):
        sb.resolve("/etc/passwd")


def test_relpath_roundtrip(tmp_path):
    sb = Sandbox(tmp_path)
    target = sb.resolve("a/b.py")
    assert sb.relpath(target).replace("\\", "/") == "a/b.py"
