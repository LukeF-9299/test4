import pytest

from gemma_agent.protocol import ProtocolError, parse_action


def test_parse_fenced_json():
    text = 'Sure.\n```json\n{"thought": "t", "action": "read_file", "args": {"path": "a.py"}}\n```'
    a = parse_action(text)
    assert a.action == "read_file"
    assert a.args["path"] == "a.py"
    assert a.thought == "t"


def test_parse_bare_json():
    a = parse_action('{"action": "final", "args": {"answer": "done"}}')
    assert a.action == "final"
    assert a.args["answer"] == "done"


def test_parse_prefers_last_block():
    text = (
        '```json\n{"action": "list_dir", "args": {}}\n```\n'
        'then\n```json\n{"action": "final", "args": {"answer": "x"}}\n```'
    )
    assert parse_action(text).action == "final"


def test_parse_embedded_braces():
    text = 'Here you go: {"action": "search", "args": {"query": "def main"}} ok'
    a = parse_action(text)
    assert a.action == "search"
    assert a.args["query"] == "def main"


def test_missing_action_raises():
    with pytest.raises(ProtocolError):
        parse_action('{"thought": "no action here"}')


def test_no_json_raises():
    with pytest.raises(ProtocolError):
        parse_action("I cannot find any structured action in this text.")


def test_default_args():
    a = parse_action('{"action": "list_dir"}')
    assert a.args == {}
